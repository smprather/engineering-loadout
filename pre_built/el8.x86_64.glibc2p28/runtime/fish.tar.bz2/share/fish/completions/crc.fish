crc completion fish | source
