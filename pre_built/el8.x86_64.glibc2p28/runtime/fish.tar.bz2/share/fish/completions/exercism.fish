exercism completion fish | source
