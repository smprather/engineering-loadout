dua completions fish | source
