require("catppuccin").load "latte"
