# az upgrade

> Upgrade Azure CLI and Extensions.
> Part of `azure-cli` (also known as `az`).
> More information: <https://learn.microsoft.com/cli/azure/reference-index#az-upgrade>.

- Upgrade Azure CLI:

`az upgrade`

- Upgrade Azure CLI and Extensions:

`az upgrade --all`

- Upgrade Azure CLI and Extensions without prompting for confirmation:

`az upgrade --all {{[-y|--yes]}}`
