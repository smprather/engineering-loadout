# az bicep

> Bicep CLI command group.
> Part of `azure-cli` (also known as `az`).
> More information: <https://learn.microsoft.com/cli/azure/bicep>.

- Install Bicep CLI:

`az bicep install`

- Build a Bicep file:

`az bicep build {{[-f|--file]}} {{path/to/file.bicep}}`

- Attempt to decompile an ARM template file to a Bicep file:

`az bicep decompile {{[-f|--file]}} {{path/to/template_file.json}}`

- Upgrade Bicep CLI to the latest version:

`az bicep upgrade`

- Display the installed version of Bicep CLI:

`az bicep version`

- List all available versions of Bicep CLI:

`az bicep list-versions`

- Uninstall Bicep CLI:

`az bicep uninstall`
