# az version

> Show the current version of Azure CLI modules and extensions.
> Part of `azure-cli` (also known as `az`).
> More information: <https://learn.microsoft.com/cli/azure/reference-index#az-version>.

- Show the current version of Azure CLI modules and extensions in JSON format:

`az version`

- Show the current version of Azure CLI modules and extensions in a given format:

`az version {{[-o|--output]}} {{json|table|tsv}}`
