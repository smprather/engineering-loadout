# behat

> A PHP framework for behavior-driven development.
> More information: <https://docs.behat.org/en/latest/user_guide/command_line_tool.html>.

- Initialize a new Behat project:

`behat --init`

- Run all tests:

`behat`

- Run all tests from the specified suite:

`behat --suite {{suite_name}}`

- Run tests with a specific output formatter:

`behat --format {{pretty|progress}}`

- Run tests and output results to a file:

`behat --out {{path/to/file}}`

- List the definitions in your test suites:

`behat --definitions`
