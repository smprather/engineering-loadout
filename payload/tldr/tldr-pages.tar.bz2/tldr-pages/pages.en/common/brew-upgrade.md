# brew upgrade

> Upgrade outdated formulae and casks.
> More information: <https://docs.brew.sh/Manpage#upgrade-options-installed_formulainstalled_cask->.

- Upgrade all outdated casks and formulae:

`brew upgrade`

- Upgrade a specific formula/cask:

`brew upgrade {{formula|cask}}`

- Print what would be upgraded, but don't actually upgrade anything:

`brew upgrade {{[-n|--dry-run]}}`

- Upgrade all outdated packages without asking for confirmation:

`brew upgrade {{[-y|--yes]}}`
