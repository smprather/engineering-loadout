#!/usr/bin/env bash
# Entry point for the AlmaLinux 8 offline-build image. Run with --network none
# and the Engineering Loadout install mounted at /opt/loadout (or LOADOUT_ROOT).
set -euo pipefail

LOADOUT=${LOADOUT_ROOT:-/opt/loadout}
for tool in cargo rustc python3.15; do
    if [ ! -x "$LOADOUT/bin/$tool" ]; then
        echo "error: $LOADOUT/bin/$tool not found" >&2
        echo "mount the Engineering Loadout install at $LOADOUT (or set LOADOUT_ROOT)" >&2
        exit 1
    fi
done

export PATH="$LOADOUT/bin:$PATH"
: "${PYTHON:=$LOADOUT/bin/python3.15}"
export PYTHON

echo "python: $("$PYTHON" --version 2>&1)"
echo "cargo:  $(cargo --version)"
echo "rustc:  $(rustc --version)"
echo "cc:     $(cc --version | head -1)"

"$PYTHON" /src/scripts/check_vendored_crates.py

"$PYTHON" /src/tests/gen/design_gen.py \
    -o "$PWD/gen" -n "${INSTANCES:-20000}" >/dev/null

example_report=$(
    /src/scripts/run_example_offline.sh \
        --format parquet \
        --lef "$PWD/gen/design.lef" \
        --def "$PWD/gen/design.def.gz" \
        --output "$PWD/instances.parquet"
)
printf '%s\n' "$example_report"

reported=$(printf '%s\n' "$example_report" | sed -n 's/^instances: //p' | tr -d ,)
expected=$(
    "$PYTHON" -c 'import json, sys; print(json.load(open(sys.argv[1]))["counts"]["components"])' \
        "$PWD/gen/manifest.json"
)
if [ "$reported" != "$expected" ]; then
    echo "error: example reported '$reported' instances, manifest says '$expected'" >&2
    exit 1
fi

test -s "$PWD/instances.parquet"
echo "ok: $PWD/instances.parquet ($(stat -c %s "$PWD/instances.parquet") bytes)"

sdc_report=$(
    PYTHONPATH="$PWD/py" "$PYTHON" -c \
        'from sdc_tools import clocks; import sys; print("\n".join(c.name for c in clocks(sys.argv[1])))' \
        "$PWD/gen/design.sdc"
)
printf '%s\n' "$sdc_report"
if ! printf '%s\n' "$sdc_report" | grep -q '^core_clk'; then
    echo "error: sdc-tools did not report core_clk" >&2
    exit 1
fi
echo "ok: sdc-tools clocks"
