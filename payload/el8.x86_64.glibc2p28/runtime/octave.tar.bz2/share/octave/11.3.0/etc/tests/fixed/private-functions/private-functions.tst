%!assert (fcn ())
