# shellcheck shell=sh

# get current shell name by querying shell variables or looking at parent
# process name
if [ -n "${BASH:-}" ]; then
   if [ "${BASH##*/}" = 'sh' ]; then
      shell='sh'
   else
      shell='bash'
   fi
elif [ -n "${ZSH_NAME:-}" ]; then
   shell=$ZSH_NAME
else
   shell=$(/usr/bin/basename "$(/usr/bin/ps -p $$ -ocomm=)")
fi

if [ -f "/__LOADOUT_RELOC_ROOT__/lib/modules/init/$shell" ]; then
   . "/__LOADOUT_RELOC_ROOT__/lib/modules/init/$shell"
else
   . '/__LOADOUT_RELOC_ROOT__/lib/modules/init/sh'
fi
