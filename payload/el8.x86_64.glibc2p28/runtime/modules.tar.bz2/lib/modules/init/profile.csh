if ($?tcsh) then
   source '/__LOADOUT_RELOC_ROOT__/lib/modules/init/tcsh'
else
   source '/__LOADOUT_RELOC_ROOT__/lib/modules/init/csh'
endif
