; inherits: json
