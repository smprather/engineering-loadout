; inherits: ecma
