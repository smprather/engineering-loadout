(identifier) @variable

;; Methods

(method_declaration name: (identifier) @function)
(local_function_statement name: (identifier) @function)

;; Types

(interface_declaration name: (identifier) @type)
(class_declaration name: (identifier) @type)
(enum_declaration name: (identifier) @type)
(struct_declaration (identifier) @type)
(record_declaration (identifier) @type)
(namespace_declaration name: (identifier) @namespace)

(generic_name (identifier) @type)
(type_parameter (identifier) @type.parameter)
(parameter type: (identifier) @type)
(type_argument_list (identifier) @type)
(as_expression right: (identifier) @type)
(is_expression right: (identifier) @type)

(constructor_declaration name: (identifier) @constructor)
(destructor_declaration name: (identifier) @constructor)

(_ type: (identifier) @type)

(base_list (identifier) @type)

(predefined_type) @type.builtin

;; Enum
(enum_member_declaration (identifier) @type.enum.variant)

;; Literals

(real_literal) @constant.numeric.float
(integer_literal) @constant.numeric.integer
(character_literal) @constant.character

[
  (string_literal)
  (raw_string_literal)
  (verbatim_string_literal)
  (interpolated_string_expression)
  (interpolation_start)
  (interpolation_quote)
 ] @string

(escape_sequence) @constant.character.escape

(boolean_literal) @constant.builtin.boolean
(null_literal) @constant.builtin

;; Comments

(comment) @comment

;; Tokens

[
  ";"
  "."
  ","
] @punctuation.delimiter

[
  "--"
  "-"
  "-="
  "&"
  "&="
  "&&"
  "+"
  "++"
  "+="
  "<"
  "<="
  "<<"
  "<<="
  "="
  "=="
  "!"
  "!="
  "=>"
  ">"
  ">="
  ">>"
  ">>="
  ">>>"
  ">>>="
  "|"
  "|="
  "||"
  "?"
  "??"
  "??="
  "^"
  "^="
  "~"
  "*"
  "*="
  "/"
  "/="
  "%"
  "%="
  ":"
  ".." ; range, and C# 12 collection-expression spread (`..rest`)
] @operator

[
  "("
  ")"
  "["
  "]"
  "{"
  "}"
  (interpolation_brace)
]  @punctuation.bracket

;; Keywords

[
  (modifier)
  "this"
  (implicit_type)
] @keyword

[
  "add"
  "alias"
  "as"
  "base"
  "break"
  "catch"
  "checked"
  "class"
  "continue"
  "default"
  "delegate"
  "do"
  "enum"
  "event"
  "explicit"
  "extern"
  "finally"
  "for"
  "foreach"
  "global"
  "goto"
  "implicit"
  "interface"
  "is"
  "lock"
  "namespace"
  "notnull"
  "operator"
  "params"
  "return"
  "remove"
  "sizeof"
  "stackalloc"
  "static"
  "struct"
  "throw"
  "try"
  "typeof"
  "unchecked"
  "using"
  "while"
  "new"
  "await"
  "in"
  "yield"
  "get"
  "set"
  "when"
  "out"
  "ref"
  "from"
  "where"
  "select"
  "record"
  "init"
  "with"
  "let"
  ;; LINQ query clauses
  "group"
  "by"
  "into"
  "join"
  "on"
  "equals"
  "orderby"
  "ascending"
  "descending"
] @keyword

[
  "case"
  "else"
  "if"
  "switch"
  "when"
] @keyword.control.conditional

;; Pattern matching combinators (`x is not null`, `> 0 and < 10`)

[
  "and"
  "or"
  "not"
] @keyword.operator

;; Preprocessor directives

[
  "#define"
  "#undef"
  "#if"
  "#elif"
  "#else"
  "#endif"
  "#region"
  "#endregion"
  "#error"
  "#warning"
  "#line"
  "#nullable"
  "#pragma"
] @keyword.directive

;; Attribute

(attribute name: (identifier) @attribute)
; Named attribute argument `[Attr(Name = value)]`.
(attribute_argument name: (identifier) @variable.other.member)

;; Parameters

(parameter
  name: (identifier) @variable.parameter)

;; Type constraints

(type_parameter_constraints_clause (identifier) @type.parameter)

;; Member access. Before the method-call rules below so `obj.Method()` reclaims
;; @function, while a plain `obj.field` stays a member.
(member_access_expression name: (identifier) @variable.other.member)

;; Method calls

(invocation_expression (member_access_expression name: (identifier) @function))
; Bare calls (`Method()` without a receiver)
(invocation_expression function: (identifier) @function)
