#!/bin/sh
set -eu

usage() {
    cat <<'EOF'
Usage: ./install.sh [--prefix PATH] [--force] [--no-test]

Installs the packaged Python 3.15.0 tree into PATH, defaulting to "$HOME/.local".
The package is relocatable across EL8-compatible home directories.

Options:
  --prefix PATH  Install destination prefix. Default: "$HOME/.local"
  --force        Allow replacing existing Python 3.15 files in the prefix.
  --no-test      Skip the post-install import smoke test.
EOF
}

prefix=${HOME}/.local
force=0
test_install=1

while [ "$#" -gt 0 ]; do
    case "$1" in
        --prefix)
            [ "$#" -ge 2 ] || { echo "missing argument for --prefix" >&2; exit 2; }
            prefix=$2
            shift 2
            ;;
        --force)
            force=1
            shift
            ;;
        --no-test)
            test_install=0
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "unknown argument: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

case "$prefix" in
    /*) ;;
    *) echo "--prefix must be an absolute path" >&2; exit 2 ;;
esac

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
payload=$script_dir/local

[ -d "$payload" ] || { echo "payload directory not found: $payload" >&2; exit 1; }

conflicts="
$prefix/bin/python3.15
$prefix/lib/python3.15
$prefix/include/python3.15
$prefix/lib/libpython3.15.so.1.0
"

if [ "$force" -ne 1 ]; then
    for p in $conflicts; do
        if [ -e "$p" ] || [ -L "$p" ]; then
            echo "refusing to overwrite existing path: $p" >&2
            echo "rerun with --force to replace Python 3.15 files" >&2
            exit 1
        fi
    done
fi

if [ "$force" -eq 1 ]; then
    rm -rf \
        "$prefix/bin/python3.15" "$prefix/bin/python3" \
        "$prefix/bin/python3.15-config" "$prefix/bin/python3-config" \
        "$prefix/bin/pip3.15" "$prefix/bin/pip3" \
        "$prefix/bin/idle3.15" "$prefix/bin/idle3" \
        "$prefix/bin/pydoc3.15" "$prefix/bin/pydoc3" \
        "$prefix/lib/python3.15" "$prefix/include/python3.15" \
        "$prefix/lib/libpython3.15.so" "$prefix/lib/libpython3.15.so.1.0" \
        "$prefix/lib/libpython3.so" \
        "$prefix/lib/pkgconfig/python-3.15.pc" \
        "$prefix/lib/pkgconfig/python-3.15-embed.pc" \
        "$prefix/lib/pkgconfig/python3.pc" \
        "$prefix/lib/pkgconfig/python3-embed.pc" \
        "$prefix/share/man/man1/python3.15.1" "$prefix/share/man/man1/python3.1"
fi

mkdir -p "$prefix"

if command -v rsync >/dev/null 2>&1; then
    rsync -a "$payload"/ "$prefix"/
else
    (cd "$payload" && tar cf - .) | (cd "$prefix" && tar xpf -)
fi

find "$prefix/lib/python3.15" -type f -name '*.pyc' -delete 2>/dev/null || true
find "$prefix/lib/python3.15" -type d -name __pycache__ -empty -delete 2>/dev/null || true

bad_links=$(
    for root in \
        "$prefix/bin/python3.15" "$prefix/bin/python3" \
        "$prefix/bin/python3.15-config" "$prefix/bin/python3-config" \
        "$prefix/bin/pip3.15" "$prefix/bin/pip3" \
        "$prefix/bin/idle3.15" "$prefix/bin/idle3" \
        "$prefix/bin/pydoc3.15" "$prefix/bin/pydoc3" \
        "$prefix/lib/python3.15" "$prefix/include/python3.15" \
        "$prefix/lib/pkgconfig/python-3.15.pc" \
        "$prefix/lib/pkgconfig/python-3.15-embed.pc" \
        "$prefix/lib/pkgconfig/python3.pc" \
        "$prefix/lib/pkgconfig/python3-embed.pc" \
        "$prefix/lib/libpython3.15.so" "$prefix/lib/libpython3.15.so.1.0" \
        "$prefix/lib/libpython3.so" \
        "$prefix/lib/libssl.so" "$prefix/lib/libssl.so.3" \
        "$prefix/lib/libcrypto.so" "$prefix/lib/libcrypto.so.3" \
        "$prefix/lib/libffi.so" "$prefix/lib/libffi.so.8" "$prefix/lib/libffi.so.8.1.3" \
        "$prefix/lib/libexpat.so" "$prefix/lib/libexpat.so.1" "$prefix/lib/libexpat.so.1.12.0" \
        "$prefix/lib/libgdbm.so" "$prefix/lib/libgdbm.so.6" "$prefix/lib/libgdbm.so.6.0.0" \
        "$prefix/lib/libgdbm_compat.so" "$prefix/lib/libgdbm_compat.so.4" "$prefix/lib/libgdbm_compat.so.4.0.0" \
        "$prefix/lib/libhistory.so" "$prefix/lib/libhistory.so.8" "$prefix/lib/libhistory.so.8.3" \
        "$prefix/lib/libmpdec.so" "$prefix/lib/libmpdec.so.4" "$prefix/lib/libmpdec.so.4.0.1" \
        "$prefix/lib/libreadline.so" "$prefix/lib/libreadline.so.8" "$prefix/lib/libreadline.so.8.3" \
        "$prefix/lib/libsqlite3.so" "$prefix/lib/libsqlite3.so.0" "$prefix/lib/libsqlite3.so.3.53.1" \
        "$prefix/lib/libtcl8.6.so" "$prefix/lib/libtk8.6.so" \
        "$prefix/lib/libzstd.so" "$prefix/lib/libzstd.so.1" "$prefix/lib/libzstd.so.1.5.7" \
        "$prefix/lib/tcl8.6" "$prefix/lib/tk8.6" "$prefix/lib/tcl8" \
        "$prefix/lib/itcl4.3.4" "$prefix/lib/tdbc1.1.12" "$prefix/lib/thread2.8.12" \
        "$prefix/lib/sqlite3.50.4" "$prefix/lib/ossl-modules" "$prefix/lib/engines-3"
    do
        [ -e "$root" ] || [ -L "$root" ] || continue
        find "$root" -xdev -type l -lname '/*' -print 2>/dev/null || true
    done
)

if [ -n "$bad_links" ]; then
    echo "absolute symlinks found after install:" >&2
    printf '%s\n' "$bad_links" >&2
    exit 1
fi

if [ "$test_install" -eq 1 ]; then
    env -u LD_LIBRARY_PATH PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 "$prefix/bin/python3.15" - <<'PY'
import ssl
import sqlite3
import pyexpat
import _tkinter
import _ctypes
import _decimal
import _gdbm
import readline
import _zstd
print("python portable install ok")
print("openssl", ssl.OPENSSL_VERSION)
print("sqlite", sqlite3.sqlite_version)
print("expat", pyexpat.EXPAT_VERSION)
print("tk", _tkinter.TCL_VERSION, _tkinter.TK_VERSION)
PY
    env -u LD_LIBRARY_PATH PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 "$prefix/bin/python3.15" -m pip --version
    find "$prefix/lib/python3.15" -type f -name '*.pyc' -delete 2>/dev/null || true
    find "$prefix/lib/python3.15" -type d -name __pycache__ -empty -delete 2>/dev/null || true
fi

cat <<EOF
Installed Python 3.15.0 into:
  $prefix

Add this to PATH if needed:
  export PATH="$prefix/bin:\$PATH"
EOF
