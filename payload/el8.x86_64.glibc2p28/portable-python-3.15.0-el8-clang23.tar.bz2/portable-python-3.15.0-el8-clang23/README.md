# Portable Python 3.15.0 for EL8

This archive contains a relocatable CPython 3.15.0 install built on EL8 with
Clang/LLVM 23, PGO, full LTO, and BOLT.

Install into the current user's home:

```sh
tar xf python-3.15.0-el8-clang23-portable.tar.gz
cd portable-python-3.15.0-el8-clang23
./install.sh
```

Install somewhere else:

```sh
./install.sh --prefix "$HOME/.local"
```

Use `--force` only if replacing an existing Python 3.15 install in that prefix.
The installer does not require root and defaults to `$HOME/.local`.

After install:

```sh
export PATH="$HOME/.local/bin:$PATH"
python3.15 --version
python3.15 -m pip --version
```
