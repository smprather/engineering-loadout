# Rebuilding portable Python 3.15.0 on EL8

This is intentionally EL8-specific. It documents the build that produced a
portable `~/.local` Python 3.15.0 install on an EL8-compatible system
(AlmaLinux/RHEL/Rocky/Oracle Linux 8). The important constraints are:

- install under `~/.local`
- do not hardcode the user name, user id, or `/home/<user>` in installed files
- do not leave absolute symlinks in the Python install scope
- make runtime lookup work without `LD_LIBRARY_PATH`
- build missing or too-old EL8 dependencies from source
- enable PGO, full LTO, and BOLT

Set these variables first and keep using them. The examples assume the CPython
source tree is already unpacked and contains this `BUILD.md`.

```sh
export CPYTHON_SRC="$PWD"
export DEPS=/tmp/cpython3150-deps
export PREFIX=$DEPS/prefix
export MAKE_JOBS=24
export BUILD_USER=$(id -un)
export PORTABLE_AUDIT_PATTERN="/home/$BUILD_USER|$BUILD_USER|/tmp/cpython3150-deps"
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
cd "$CPYTHON_SRC"
```

## Required system tools

Install EL8 package dependencies. These package names are EL8/RHEL-family
names, not Fedora/Debian names:

```sh
sudo dnf install -y \
  gcc-toolset-14 make perl perl-IPC-Cmd perl-Time-Piece \
  ncurses-devel xz-devel bzip2-devel zlib-devel libuuid-devel \
  libX11-devel libXft-devel fontconfig-devel freetype-devel \
  findutils file pkgconf-pkg-config
```

Use the complete Clang/LLVM 23 toolchain from `/usr/local/bin`:

```sh
/usr/local/bin/clang-23
/usr/local/bin/clang++
/usr/local/bin/llvm-profdata
/usr/local/bin/llvm-ar
/usr/local/bin/llvm-ranlib
/usr/local/bin/llvm-bolt
/usr/local/bin/merge-fdata
~/.local/bin/patchelf
```

Verify these exist before starting:

```sh
command -v clang-23
command -v clang++
command -v llvm-profdata
command -v llvm-ar
command -v llvm-ranlib
command -v llvm-bolt
command -v merge-fdata
command -v patchelf
```

The build assumes these EL8 runtime paths exist:

```text
/lib64/ld-linux-x86-64.so.2
/lib64/libc.so.6
/etc/pki/tls/certs/ca-bundle.crt
```

The CA bundle path is EL8-specific and is set in `sitecustomize.py` after
install.

## LLVM and BOLT requirements

This build is LLVM-specific. Do not mix an incomplete LLVM install with this
configuration. The successful rebuild used LLVM 23 from `/usr/local/bin` for
compiling, PGO/LTO, archive tools, and BOLT. The observed LLVM version was
`23.0.0git` from commit `e6c316e374e7380415e7abb15e8816b9027307b1`.

Use these exact tool roles:

```sh
export CC=/usr/local/bin/clang-23
export CXX=/usr/local/bin/clang++
export AR=/usr/local/bin/llvm-ar
export RANLIB=/usr/local/bin/llvm-ranlib
export LLVM_PROFDATA=/usr/local/bin/llvm-profdata
export LLVM_BOLT=/usr/local/bin/llvm-bolt
export MERGE_FDATA=/usr/local/bin/merge-fdata
export LDFLAGS="-fuse-ld=lld -L$PREFIX/lib -L$PREFIX/lib64"
```

Before configuring CPython, verify Clang can find its profiling runtime and
that BOLT is callable:

```sh
/usr/local/bin/clang-23 --version
/usr/local/bin/clang-23 --print-file-name=libclang_rt.profile-x86_64.a
/usr/local/bin/clang-23 -fprofile-instr-generate -x c - -o /tmp/clang23-prof-test <<'EOF'
int main(void) { return 0; }
EOF
/tmp/clang23-prof-test
/usr/local/bin/llvm-profdata --version
/usr/local/bin/llvm-bolt --version
/usr/local/bin/merge-fdata --help >/dev/null
```

For the LLVM 23 install used here, `--print-file-name=libclang_rt.profile-x86_64.a`
misleadingly printed only the literal library name, but the profile runtime was
present as:

```text
/usr/local/lib/clang/23/lib/x86_64-unknown-linux-gnu/libclang_rt.profile.a
```

The direct `-fprofile-instr-generate` compile/link smoke test is the
authoritative check.

Keep the LLVM versions coherent:

- compile and profile with Clang/LLVM 23
- use `llvm-ar` and `llvm-ranlib` from the same `/usr/local/bin` LLVM install
  for LTO objects
- use `llvm-profdata` from the same LLVM install for PGO data
- use `-fuse-ld=lld`
- do not strip `python` or `libpython3.15.so.1.0` until after CPython has
  finished the BOLT pass

`--enable-bolt` makes CPython perform the BOLT instrument/profile/rewrite flow.
It expects `llvm-bolt` and `merge-fdata` on `PATH` or in the exported variables
above. The final proof that BOLT ran is `profile-bolt-stamp` in the CPython
build tree.

## Source dependency versions

These versions were built from source:

```text
OpenSSL     3.5.6
SQLite      3.53.1  sqlite-autoconf-3530100
readline    8.3
gdbm        1.26
zstd        1.5.7
mpdecimal   4.0.1
libffi      3.4.5
Tcl/Tk      8.6.17
Expat       2.8.0
```

The tarballs used for this build are cached in `$CPYTHON_SRC/deps/src/`. If
re-downloading, save them with the exact filenames listed above. Build all
third-party dependencies into a temporary prefix, not into the CPython source
tree:

```sh
mkdir -p "$DEPS/build" "$PREFIX"
```

Do not use `deps/prefix` inside the CPython tree. `make distclean` can damage
that directory.

## Build dependencies

The general pattern is: unpack under `$DEPS/build`, configure with
`--prefix=$PREFIX`, build, install.

OpenSSL:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/openssl-3.5.6.tar.gz"
cd openssl-3.5.6
./Configure linux-x86_64 --prefix="$PREFIX" --openssldir="$PREFIX/ssl" shared
make -j"$MAKE_JOBS"
make install_sw
```

SQLite:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/sqlite-autoconf-3530100.tar.gz"
cd sqlite-autoconf-3530100
./configure --prefix="$PREFIX" --enable-shared --disable-static --enable-fts5
make -j"$MAKE_JOBS"
make install
```

readline:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/readline-8.3.tar.gz"
cd readline-8.3
./configure --prefix="$PREFIX" --enable-shared --disable-static
make -j"$MAKE_JOBS"
make install
```

gdbm:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/gdbm-1.26.tar.gz"
cd gdbm-1.26
./configure --prefix="$PREFIX" --enable-shared --disable-static
make -j"$MAKE_JOBS"
make install
```

zstd:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/zstd-1.5.7.tar.gz"
cd zstd-1.5.7
make -j"$MAKE_JOBS" prefix="$PREFIX" HAVE_ZLIB=1 HAVE_LZMA=1 HAVE_LZ4=0
make install prefix="$PREFIX"
```

mpdecimal:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/mpdecimal-4.0.1.tar.gz"
cd mpdecimal-4.0.1
./configure --prefix="$PREFIX" --enable-shared --disable-static
make -j"$MAKE_JOBS"
make install
```

libffi:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/libffi-3.4.5.tar.gz"
cd libffi-3.4.5
./configure --prefix="$PREFIX" --enable-shared --disable-static
make -j"$MAKE_JOBS"
make install
```

Tcl/Tk:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/tcl8.6.17-src.tar.gz"
cd tcl8.6.17/unix
./configure --prefix="$PREFIX" --enable-shared
make -j"$MAKE_JOBS"
make install

cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/tk8.6.17-src.tar.gz"
cd tk8.6.17/unix
./configure --prefix="$PREFIX" --enable-shared --with-tcl="$PREFIX/lib"
make -j"$MAKE_JOBS"
make install
```

Expat:

```sh
cd "$DEPS/build"
tar xf "$CPYTHON_SRC/deps/src/expat-2.8.0.tar.gz"
cd expat-2.8.0
./configure --prefix="$PREFIX" --enable-shared --disable-static
make -j"$MAKE_JOBS"
make install
```

## Configure CPython

Start from a clean CPython build directory:

```sh
cd "$CPYTHON_SRC"
make distclean || true
```

Configure with `/usr/local` as the compiled prefix. The install step overrides
this to `~/.local`; using `/usr/local` at configure time avoids baking the
current home directory into Python path fallback constants.

```sh
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
export PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig:$PREFIX/lib64/pkgconfig"
export LD_LIBRARY_PATH="$PREFIX/lib:$PREFIX/lib64"
export CC=/usr/local/bin/clang-23
export CXX=/usr/local/bin/clang++
export AR=/usr/local/bin/llvm-ar
export RANLIB=/usr/local/bin/llvm-ranlib
export LLVM_PROFDATA=/usr/local/bin/llvm-profdata
export LLVM_BOLT=/usr/local/bin/llvm-bolt
export MERGE_FDATA=/usr/local/bin/merge-fdata
export CPPFLAGS="-I$PREFIX/include"
export LDFLAGS="-fuse-ld=lld -L$PREFIX/lib -L$PREFIX/lib64"
export LIBEXPAT_CFLAGS="-I$PREFIX/include"
export LIBEXPAT_LDFLAGS="-L$PREFIX/lib -lexpat"
export LIBSQLITE3_CFLAGS="-I$PREFIX/include"
export LIBSQLITE3_LIBS="-L$PREFIX/lib -lsqlite3"
export GDBM_CFLAGS="-I$PREFIX/include"
export GDBM_LIBS="-L$PREFIX/lib -lgdbm"
export LIBMPDEC_CFLAGS="-I$PREFIX/include"
export LIBMPDEC_LIBS="-L$PREFIX/lib -lmpdec"
export LIBFFI_CFLAGS="-I$PREFIX/include"
export LIBFFI_LIBS="-L$PREFIX/lib -lffi"
export LIBZSTD_CFLAGS="-I$PREFIX/include"
export LIBZSTD_LIBS="-L$PREFIX/lib -lzstd"
export LIBREADLINE_CFLAGS="-I$PREFIX/include"
export LIBREADLINE_LIBS="-L$PREFIX/lib -lreadline -lncurses"
export TCLTK_CFLAGS="-I$PREFIX/include"
export TCLTK_LIBS="-L$PREFIX/lib -ltk8.6 -ltcl8.6 -lXft -lfontconfig -lfreetype -lX11 -ldl -lz -lpthread -lm"

./configure \
  --prefix=/usr/local \
  --enable-shared \
  --enable-optimizations \
  --with-lto=full \
  --enable-bolt \
  --enable-safety \
  --enable-loadable-sqlite-extensions \
  --enable-ipv6 \
  --enable-big-digits=30 \
  --with-pymalloc \
  --with-mimalloc \
  --with-computed-gotos \
  --with-tail-call-interp \
  --with-remote-debug \
  --with-ensurepip=upgrade \
  --with-system-expat \
  --with-system-libmpdec \
  --with-decimal-contextvar \
  --with-doc-strings \
  --with-readline=readline \
  --with-openssl="$PREFIX" \
  --with-openssl-rpath=no \
  --with-builtin-hashlib-hashes=md5,sha1,sha2,sha3,blake2
```

Confirm configure found these modules:

```text
_ssl _hashlib _sqlite3 _tkinter _ctypes _decimal _dbm _gdbm readline _zstd
pyexpat _elementtree
```

## Build with PGO, LTO, and BOLT

The PGO test runner uses multiprocessing/forkserver. Run the build outside any
sandbox that blocks process creation.

```sh
make -j"$MAKE_JOBS"
```

Expected successful signs:

- PGO training completes
- CPython invokes `/usr/local/bin/llvm-profdata` during the profile merge
- CPython invokes `llvm-bolt` and `merge-fdata`
- BOLT instruments both `python` and `libpython3.15.so.1.0`
- BOLT profile workload completes
- BOLT writes final optimized binaries
- `profile-bolt-stamp` exists

BOLT may print invalid profile data or collision warnings and still finish
successfully.

After the build, check:

```sh
test -f profile-bolt-stamp
ls -l python libpython3.15.so.1.0 profile-bolt-stamp
```

## Install into `~/.local`

Install with explicit prefix overrides:

```sh
env LD_LIBRARY_PATH="$CPYTHON_SRC:$PREFIX/lib:$PREFIX/lib64" \
  make install prefix="$HOME/.local" exec_prefix="$HOME/.local"
```

The final install target is:

```text
~/.local/bin/python3.15
~/.local/lib/libpython3.15.so.1.0
~/.local/lib/python3.15
~/.local/include/python3.15
```

## Copy runtime dependencies into `~/.local/lib`

Copy only runtime libraries and Tcl/Tk script trees. Do not copy `.la` files or
third-party pkg-config files; they contain the temporary build prefix.

```sh
cp -a \
  "$PREFIX"/lib/libexpat.so* \
  "$PREFIX"/lib/libgdbm.so* \
  "$PREFIX"/lib/libgdbm_compat.so* \
  "$PREFIX"/lib/libhistory.so* \
  "$PREFIX"/lib/libmpdec.so* \
  "$PREFIX"/lib/libreadline.so* \
  "$PREFIX"/lib/libsqlite3.so* \
  "$PREFIX"/lib/libtcl8.6.so \
  "$PREFIX"/lib/libtk8.6.so \
  "$PREFIX"/lib/libzstd.so* \
  "$PREFIX"/lib64/libcrypto.so* \
  "$PREFIX"/lib64/libssl.so* \
  "$PREFIX"/lib64/libffi.so* \
  "$HOME/.local/lib/"

cp -a \
  "$PREFIX"/lib/tcl8.6 \
  "$PREFIX"/lib/tk8.6 \
  "$PREFIX"/lib/tcl8 \
  "$PREFIX"/lib/itcl4.3.4 \
  "$PREFIX"/lib/tdbc1.1.12 \
  "$PREFIX"/lib/thread2.8.12 \
  "$PREFIX"/lib/sqlite3.50.4 \
  "$PREFIX"/lib64/ossl-modules \
  "$PREFIX"/lib64/engines-3 \
  "$HOME/.local/lib/"
```

Tcl/Tk shared libraries may be copied without owner write permission. Make them
writable before stripping or patching:

```sh
chmod u+w "$HOME/.local/lib/libtcl8.6.so" "$HOME/.local/lib/libtk8.6.so"
```

## Make rpaths relative

Strip debug records first, then set `$ORIGIN` rpaths:

```sh
P="$HOME/.local"
PATCHELF="$P/bin/patchelf"
STRIP=/opt/rh/gcc-toolset-14/root/usr/bin/strip

find "$P/bin" "$P/lib/python3.15/lib-dynload" "$P/lib" -xdev -type f \
  \( -name "python3.15" -o -name "*.so" -o -name "*.so.*" \) -print0 |
while IFS= read -r -d '' f; do
  file -b "$f" | grep -q ELF || continue
  "$STRIP" --strip-debug "$f" 2>/dev/null || true
done

"$PATCHELF" --set-rpath '$ORIGIN/../lib' "$P/bin/python3.15"

for f in "$P/lib"/*.so "$P/lib"/*.so.*; do
  [ -f "$f" ] || continue
  file -b "$f" | grep -q ELF || continue
  "$PATCHELF" --set-rpath '$ORIGIN' "$f" || true
done

for f in "$P/lib/python3.15/lib-dynload"/*.so; do
  [ -f "$f" ] || continue
  "$PATCHELF" --set-rpath '$ORIGIN/../..' "$f"
done

find "$P/lib" -mindepth 2 -maxdepth 3 -type f -name "*.so" -print0 |
while IFS= read -r -d '' f; do
  "$PATCHELF" --set-rpath '$ORIGIN:$ORIGIN/..' "$f" || true
done
```

Reassert extension-module rpaths after patching nested Tcl/OpenSSL modules:

```sh
for f in "$HOME/.local/lib/python3.15/lib-dynload"/*.so; do
  [ -f "$f" ] || continue
  "$HOME/.local/bin/patchelf" --set-rpath '$ORIGIN/../..' "$f"
done
```

## Portability cleanup

Remove bytecode caches so `.pyc` files do not preserve absolute source paths:

```sh
find "$HOME/.local/lib/python3.15" -name "*.pyc" -delete
find "$HOME/.local/lib/python3.15" -type d -name __pycache__ -empty -delete
```

Replace installed script shebangs that point at `/usr/local/bin/python3.15` with
wrappers that resolve `python3.15` next to the script at runtime:

```sh
P="$HOME/.local/bin"
for s in pip3 pip3.15; do
  cat > "$P/$s" <<'SH'
#!/bin/sh
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
exec "$HERE/python3.15" -m pip "$@"
SH
  chmod 775 "$P/$s"
done

for s in idle3 idle3.15; do
  cat > "$P/$s" <<'SH'
#!/bin/sh
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
exec "$HERE/python3.15" -m idlelib "$@"
SH
  chmod 775 "$P/$s"
done

for s in pydoc3 pydoc3.15; do
  cat > "$P/$s" <<'SH'
#!/bin/sh
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
exec "$HERE/python3.15" -m pydoc "$@"
SH
  chmod 775 "$P/$s"
done
```

Scrub generated build metadata:

```sh
P="$HOME/.local"
for f in \
  "$P/lib/python3.15/_sysconfigdata__linux_x86_64-linux-gnu.py" \
  "$P/lib/python3.15/_sysconfig_vars__linux_x86_64-linux-gnu.json" \
  "$P/lib/python3.15/config-3.15-x86_64-linux-gnu/Makefile"
do
  [ -f "$f" ] || continue
  perl -0pi -e 's#\Q$ENV{CPYTHON_SRC}\E#/usr/local/src/cpython-3.15.0#g;
                s#\Q$ENV{HOME}/.local\E#~/.local#g;
                s#/tmp/cpython3150-deps/prefix#/usr/local#g;
                s#-fprofile-instr-use=/usr/local/src/cpython-3\.14\.4/code\.profclangd##g;
                s#LD_LIBRARY_PATH[^"'\''\n\t ]+ ?##g;
                s#PKG_CONFIG_PATH=/usr/local/lib/pkgconfig:/usr/local/lib64/pkgconfig#PKG_CONFIG_PATH=/usr/local/lib/pkgconfig#g' "$f"
done

perl -0pi -e 's#/usr/local/bin/python3\.14#python3.15#g' \
  "$P/lib/python3.15/_sysconfigdata__linux_x86_64-linux-gnu.py" \
  "$P/lib/python3.15/_sysconfig_vars__linux_x86_64-linux-gnu.json" \
  "$P/lib/python3.15/build-details.json"

perl -0pi -e 's#/usr/local/bin/python3\.14#/usr/bin/env python3.15#g' \
  "$P/lib/python3.15/config-3.15-x86_64-linux-gnu/python-config.py"
```

Remove static development artifacts if they still contain source paths:

```sh
rm -f \
  "$HOME/.local/lib/python3.15/config-3.15-x86_64-linux-gnu/libpython3.15.a" \
  "$HOME/.local/lib/python3.15/config-3.15-x86_64-linux-gnu/python.o"
```

Patch embedded temporary prefixes in copied runtime dependency libraries with
same-length non-user placeholders:

```sh
for f in \
  "$HOME/.local/lib/libcrypto.so.3" \
  "$HOME/.local/lib/libtcl8.6.so" \
  "$HOME/.local/lib/libtk8.6.so" \
  "$HOME/.local/lib/libzstd.so.1.5.7"
do
  [ -f "$f" ] || continue
  perl -0pi -e 's#/tmp/cpython3150-deps/prefix#/opt/cpython3150-portablelib#g;
                s#/tmp/cpython3150-deps/build#/opt/cpython3150-buildxxxxx#g' "$f"
done
```

Add a relocatable runtime hook:

```sh
cat > "$HOME/.local/lib/python3.15/sitecustomize.py" <<'PY'
import os
import sys

_prefix = getattr(sys, "base_prefix", sys.prefix)
_lib = os.path.join(_prefix, "lib")
os.environ.setdefault("OPENSSL_MODULES", os.path.join(_lib, "ossl-modules"))
os.environ.setdefault("TCL_LIBRARY", os.path.join(_lib, "tcl8.6"))
os.environ.setdefault("TK_LIBRARY", os.path.join(_lib, "tk8.6"))
for _cand in (
    "/etc/pki/tls/certs/ca-bundle.crt",   # RHEL / AlmaLinux / Rocky (EL8)
    "/etc/pki/tls/cert.pem",              # RHEL alt layout
    "/etc/ssl/certs/ca-certificates.crt",  # Debian / Ubuntu / Arch
    "/etc/ssl/cert.pem",                  # Arch openssl pkg, macOS Homebrew
):
    if os.path.exists(_cand):
        os.environ.setdefault("SSL_CERT_FILE", _cand)
        break
PY
```

Make Python pkg-config metadata relocatable:

```sh
for f in \
  "$HOME/.local/lib/pkgconfig/python-3.15.pc" \
  "$HOME/.local/lib/pkgconfig/python-3.15-embed.pc"
do
  [ -f "$f" ] || continue
  sed -i 's#^prefix=.*#prefix=${pcfiledir}/../..#;
          s#^exec_prefix=.*#exec_prefix=${prefix}#' "$f"
done
```

## Audits

Run these before considering the install portable:

```sh
P="$HOME/.local"

rg -a -n --glob '!**/__pycache__/**' --glob '!*.pyc' \
  "$PORTABLE_AUDIT_PATTERN|/usr/local/bin/python3.15" \
  "$P/bin/python3.15" \
  "$P/bin/python3.15-config" \
  "$P/bin/python3-config" \
  "$P/bin/idle3.15" \
  "$P/bin/pydoc3.15" \
  "$P/bin/pip3.15" \
  "$P/bin/pip3" \
  "$P/lib/pkgconfig/python-3.15.pc" \
  "$P/lib/pkgconfig/python-3.15-embed.pc" \
  "$P/lib/python3.15" \
  "$P/include/python3.15"

for f in \
  "$P/bin/python3.15" \
  "$P/lib/libpython3.15.so.1.0" \
  "$P/lib/python3.15/lib-dynload/"*.so \
  "$P/lib/libcrypto.so.3" \
  "$P/lib/libtcl8.6.so" \
  "$P/lib/libtk8.6.so" \
  "$P/lib/libzstd.so.1.5.7" \
  "$P/lib/"*/*.so
do
  [ -e "$f" ] || continue
  if strings -a "$f" | rg -q "$PORTABLE_AUDIT_PATTERN|/usr/local/bin/python3.15"; then
    echo "$f"
    strings -a "$f" | rg "$PORTABLE_AUDIT_PATTERN|/usr/local/bin/python3.15" | sed -n '1,4p'
  fi
done

find "$P/lib/python3.15" -name "*.pyc" -print

find "$P/bin" -maxdepth 1 \
  \( -name 'python3*' -o -name 'pip3*' -o -name 'idle3*' -o -name 'pydoc3*' -o -name '2to3*' \) \
  -type l -lname '/*' -print

find "$P/lib/python3.15" "$P/lib/pkgconfig" "$P/include/python3.15" "$P/lib" \
  -xdev -type l -lname '/*' -print
```

The expected output is empty, except `rg` exits non-zero when there are no
matches.

Check rpaths:

```sh
for f in \
  "$HOME/.local/bin/python3.15" \
  "$HOME/.local/lib/libpython3.15.so.1.0" \
  "$HOME/.local/lib/python3.15/lib-dynload/_ssl"*.so \
  "$HOME/.local/lib/python3.15/lib-dynload/_sqlite3"*.so \
  "$HOME/.local/lib/python3.15/lib-dynload/_tkinter"*.so
do
  printf '%s -> ' "$f"
  "$HOME/.local/bin/patchelf" --print-rpath "$f"
done
```

Expected:

```text
python3.15 -> $ORIGIN/../lib
libpython3.15.so.1.0 -> $ORIGIN
lib-dynload modules -> $ORIGIN/../..
```

## Smoke tests

Run without `LD_LIBRARY_PATH`:

```sh
env -u LD_LIBRARY_PATH PYTHONDONTWRITEBYTECODE=1 "$HOME/.local/bin/python3.15" - <<'PY'
import os
import sys
import ssl
import sqlite3
import pyexpat
import _tkinter
import _ctypes
import _decimal
import _gdbm
import readline
import _zstd

print("python", sys.version.split()[0])
print("prefix", sys.prefix)
print("openssl", ssl.OPENSSL_VERSION)
print("ssl_cert_file", os.environ.get("SSL_CERT_FILE"))
print("sqlite", sqlite3.sqlite_version)
print("expat", pyexpat.EXPAT_VERSION)
print("tk", _tkinter.TCL_VERSION, _tkinter.TK_VERSION)
PY

env -u LD_LIBRARY_PATH PYTHONDONTWRITEBYTECODE=1 \
  "$HOME/.local/bin/python3.15" -m pip --version

"$HOME/.local/bin/python3.15-config" --prefix --ldflags --includes

PKG_CONFIG_PATH="$HOME/.local/lib/pkgconfig" \
  pkg-config --cflags --libs python-3.15-embed
```

Known good output included:

```text
python 3.15.0
openssl OpenSSL 3.5.6 7 Apr 2026
sqlite 3.53.1
expat expat_2.8.0
tk 8.6 8.6
pip 26.0.1
```

Clean any `.pyc` files created by smoke tests:

```sh
find "$HOME/.local/lib/python3.15" -name "*.pyc" -delete
find "$HOME/.local/lib/python3.15" -type d -name __pycache__ -empty -delete
```

## What did not work

GCC with `--with-tail-call-interp` did not work. CPython reported that the
compiler did not support the required tail-call interpreter feature. Resolution:
use Clang 23 and keep `--with-tail-call-interp`.

The initial Clang 23 profile-runtime diagnostic was misleading:
`clang-23 --print-file-name=libclang_rt.profile-x86_64.a` printed only the
literal library name. The actual runtime was present as
`/usr/local/lib/clang/23/lib/x86_64-unknown-linux-gnu/libclang_rt.profile.a`,
and a direct `-fprofile-instr-generate` compile/link test succeeded.
Resolution: use the compile/link smoke test as the real check for this LLVM 23
install.

Mixing LLVM tool versions is risky for this build. PGO and LTO depend on Clang,
`llvm-profdata`, `llvm-ar`, `llvm-ranlib`, and `lld` agreeing on object/profile
formats. Resolution: pin compile/profile/archive tools to the LLVM 23
`/usr/local/bin` install and use `-fuse-ld=lld`.

GNU `ar`/`ranlib` are the wrong defaults for a full-LTO LLVM build. They can
leave archives in a form that is less reliable for LLVM's linker pipeline.
Resolution: export `AR=/usr/local/bin/llvm-ar` and
`RANLIB=/usr/local/bin/llvm-ranlib` before configure.

The inherited `PATH` contained a Windows/NVIDIA path segment with a space, and
`env` failed with `Files/NVIDIA: No such file or directory`. Resolution: set a
minimal EL8 build path, `PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin`,
before configure and build commands.

BOLT tool discovery is brittle if only `llvm-bolt` exists but `merge-fdata` is
missing. Resolution: verify both before configure and export `LLVM_BOLT` and
`MERGE_FDATA` explicitly.

Stripping or patching the executable before BOLT completes would invalidate the
profile/rewrite flow. Resolution: do all stripping and `patchelf` work only
after `profile-bolt-stamp` exists and `make install` has completed.

Using the system Expat was not good enough. PGO training hit the old EL8 Expat
behavior. Resolution: build Expat 2.8.0 from source and force CPython to use it
with `LIBEXPAT_CFLAGS`, `LIBEXPAT_LDFLAGS`, and `--with-system-expat`.

Running the PGO build inside the restricted sandbox failed with a
`multiprocessing` forkserver `PermissionError: Operation not permitted`.
Resolution: run `make -j"$MAKE_JOBS"` outside that sandbox.

Clang 23 profile-use emitted `-Wprofile-instr-out-of-date` for one mismatched
function. Resolution: treat it as non-fatal when the PGO training run and final
build complete successfully.

Putting dependencies under `deps/prefix` inside the CPython source tree was a
bad idea because `make distclean` can damage generated dependency files.
Resolution: build dependencies under `/tmp/cpython3150-deps/prefix`.

Installing with the real home directory as CPython's configure prefix would
hardcode `/home/<user>` into generated metadata and path fallback strings.
Resolution: configure with `--prefix=/usr/local`, then install with
`make install prefix="$HOME/.local" exec_prefix="$HOME/.local"`.

OpenSSL, Tcl/Tk, and zstd kept temporary build prefixes in their shared
libraries. Resolution: copy runtime files into `~/.local/lib`, use relative
rpaths, add `sitecustomize.py` to set runtime module/script locations from
`sys.base_prefix`, and replace leftover temporary strings with same-length
non-user placeholders.

The first rpath cleanup pass set correct extension-module rpaths and then
overwrote them while patching nested `.so` files. `_sqlite3` could not find
`libsqlite3.so` without `LD_LIBRARY_PATH`. Resolution: reassert
`$ORIGIN/../..` on every `lib-dynload` extension after all other nested rpath
patching.

`ensurepip` installed `pip`, `idle`, and `pydoc` scripts with
`/usr/local/bin/python3.15` shebangs. Resolution: replace them with shell
wrappers that find `python3.15` next to the wrapper at runtime.

The installed `libpython3.15.a` and `python.o` kept source-path strings even
after stripping debug info. They are not needed for the shared runtime and made
the install fail the portability audit. Resolution: remove them from the
portable install.

`ensurepip` and import smoke tests create `.pyc` files that contain absolute
source paths. Resolution: delete all `.pyc` files and empty `__pycache__`
directories after install and after verification.

## JIT (added for 3.15)

3.15 is configured with `--enable-experimental-jit=yes-off`: the JIT is
compiled in, disabled by default, and enabled per process with
`PYTHON_JIT=1` (`sys._jit.is_available()` / `is_enabled()` report state).

Two build prerequisites beyond the 3.14 recipe:

1. `llvm-dwarfdump` — the JIT's unwind-info generator
   (`Tools/jit/_dwarf.py`) needs it, but the LLVM 23 toolchain ships every
   tool except this one. Built from the LLVM 23 source tree with
   `cmake -S llvm -B build -G Ninja -DLLVM_TARGETS_TO_BUILD=X86
   -DLLVM_INCLUDE_TESTS=OFF ... && cmake --build build --target llvm-dwarfdump`
   and put on PATH ahead of the toolchain.
2. Upstream pins LLVM **21** in `Tools/jit/_llvm.py` (`_LLVM_VERSION` and a
   `--version` regex in `_find_tool`); it was patched to **23** to match this
   toolchain (same class as python-build-standalone's version patch). The
   mismatch is only a printed warning; the version regex is the real gate.
3. The trimmed `llvm-project` source checkout has no `third-party/`, and
   `lib/Support/SipHash.cpp` includes `siphash/SipHash.h`. Upstream's
   `third-party/siphash` is a plain directory (not a submodule); fetch
   `third-party/siphash/include/siphash/SipHash.h` from upstream and place it
   under the source root (or a merged source tree) before configuring.
