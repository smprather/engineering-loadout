"""Core data pipeline: load files, build series registry, align, evaluate expressions."""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from time_plot.expr_parser import (
    EvalResult,
    evaluate,
    parse_expr_def,
)
from time_plot.models import SampleMode, SeriesData
from time_plot.plugin_system import ParserPlugin, select_plugin


# ---------------------------------------------------------------------------
# Public data structures
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class FileGroup:
    """A set of source files sharing the same filter."""
    files: list[Path]
    glob_filter: str | None = None    # from -F; None means '*' (all)
    regex_filter: str | None = None   # from -R


@dataclass(slots=True)
class ExpressionDef:
    """A named expression from -e 'name=expr'."""
    name: str
    expr_text: str


@dataclass(slots=True)
class AlignedTrace:
    """A single time-series after alignment to the global x-grid."""
    registry_key: str           # realpath|series_name
    legend_name: str            # display name
    source_name: str            # plugin source_name or 'expr[...]'
    source_path: Path | None    # None for expression results
    y_label: str
    y_unit: str
    y_unit_label: str
    y: np.ndarray
    y_display_prefix: str | None = None
    sample_mode: SampleMode = "linear"
    logic_states: np.ndarray | None = None


@dataclass(slots=True)
class AlignedPlotData:
    x_seconds: np.ndarray
    traces: list[AlignedTrace]
    x_timestep_seconds: float | None = None
    x_display_prefix: str | None = None


# ---------------------------------------------------------------------------
# Series registry
# ---------------------------------------------------------------------------

@dataclass
class _RegistryEntry:
    series: SeriesData
    source_path: Path
    plugin_name: str


def _registry_key(path: Path, series_name: str) -> str:
    return f"{path.resolve()}|{series_name}"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def list_series_for_groups(
    groups: list[FileGroup],
    plugins: list[ParserPlugin],
    parser_options: dict[str, str] | None = None,
    case_insensitive: bool = False,
) -> dict[Path, list[str]]:
    """Return filtered series names per file without loading data.

    For plugins that implement list_series, the listing is cheap (no data load).
    For plugins that don't, parse() is called with selected=None and names are
    collected from the returned SeriesData objects.
    """
    opts = parser_options or {}
    result: dict[Path, list[str]] = {}

    for group in groups:
        for file_path in group.files:
            plugin = select_plugin(file_path, plugins)
            if plugin.list_series is not None:
                all_names = plugin.list_series(file_path, opts)
            else:
                series_list = plugin.parse(file_path, opts, None)
                all_names = [s.name for s in series_list]

            filtered = _apply_filter(all_names, group, case_insensitive=case_insensitive)
            result[file_path] = filtered

    return result


def load_file_groups(
    groups: list[FileGroup],
    plugins: list[ParserPlugin],
    parser_options: dict[str, str] | None = None,
    case_insensitive: bool = False,
) -> dict[str, _RegistryEntry]:
    """Load all files from all groups, applying filters, and return the series registry."""
    opts = parser_options or {}
    registry: dict[str, _RegistryEntry] = {}

    for group in groups:
        for file_path in group.files:
            plugin = select_plugin(file_path, plugins)
            selected = _select_series(file_path, plugin, opts, group, case_insensitive=case_insensitive)
            series_list = plugin.parse(file_path, opts, selected)
            # Post-parse filtering: plugins without list_series() (CSV, TXT,
            # SPICE, third-party) ignore `selected`, so filters must be
            # applied here. Applied unconditionally when a filter is present
            # so listing and plotting agree even if a plugin ignores selected.
            if group.glob_filter is not None or group.regex_filter is not None:
                names = [s.name for s in series_list]
                allowed = set(_apply_filter(names, group, case_insensitive=case_insensitive))
                series_list = [s for s in series_list if s.name in allowed]
            for series in series_list:
                key = _registry_key(file_path, series.name)
                if key in registry:
                    raise ValueError(
                        f"Duplicate series key in registry: {key!r}"
                    )
                registry[key] = _RegistryEntry(
                    series=series,
                    source_path=file_path,
                    plugin_name=plugin.plugin_name,
                )

    if not registry and any(g.glob_filter is not None or g.regex_filter is not None for g in groups):
        raise ValueError("Filter matched no series")
    return registry


def _select_series(
    file_path: Path,
    plugin: ParserPlugin,
    opts: dict[str, str],
    group: FileGroup,
    case_insensitive: bool = False,
) -> list[str] | None:
    """Return the list of series names to extract, or None to load all."""
    has_filter = group.glob_filter is not None or group.regex_filter is not None
    if not has_filter:
        # No filter — plugins without list_series load everything
        return None

    if plugin.list_series is None:
        # Plugin can't enumerate series; load all and filter post-parse.
        # Caller (load_file_groups) handles post-parse filtering.
        return None

    all_names = plugin.list_series(file_path, opts)
    return _apply_filter(all_names, group, case_insensitive=case_insensitive)


def _apply_filter(names: list[str], group: FileGroup, case_insensitive: bool = False) -> list[str]:
    result = names
    if group.glob_filter is not None:
        pat = _glob_to_match_pattern(group.glob_filter)
        if case_insensitive:
            result = [n for n in result if fnmatch.fnmatch(n.lower(), pat.lower())]
        else:
            result = [n for n in result if fnmatch.fnmatch(n, pat)]
    if group.regex_filter is not None:
        flags = re.IGNORECASE if case_insensitive else 0
        rx = re.compile(group.regex_filter, flags)
        result = [n for n in result if rx.search(n)]
    return result


def _glob_to_match_pattern(pat: str) -> str:
    """If pattern has no glob chars, treat as *pat* (substring)."""
    if not any(c in pat for c in "*?[]"):
        return f"*{pat}*"
    return pat


# ---------------------------------------------------------------------------
# Alignment
# ---------------------------------------------------------------------------

def align_registry(
    registry: dict[str, _RegistryEntry],
) -> AlignedPlotData:
    """Align all registry entries to a common x-grid."""
    if not registry:
        raise ValueError("No series loaded")

    entries = list(registry.items())
    series_list = [e.series for _, e in entries]

    for key, entry in entries:
        _validate_input_x_before_merge(entry.series.x, entry.source_path)
        entry.series.x, entry.series.y, entry.series.logic_states = _merge_duplicate_x(
            entry.series.x,
            entry.series.y,
            entry.series.logic_states,
            entry.series.sample_mode,
        )
        _validate_strictly_increasing_x(entry.series.x, entry.source_path)

    x_arrays = [s.x for s in series_list]
    x_grid = np.unique(np.concatenate(x_arrays))
    dt = float(np.min(np.diff(x_grid))) if x_grid.size > 1 else 0.0

    traces: list[AlignedTrace] = []
    for key, entry in entries:
        s = entry.series
        if s.sample_mode == "step":
            y_grid = _step_onto_grid(s.x, s.y, x_grid)
            logic_states_grid = _step_states_onto_grid(s.x, s.logic_states, x_grid)
        else:
            y_grid = _interpolate_onto_grid(s.x, s.y, x_grid)
            logic_states_grid = None
        traces.append(AlignedTrace(
            registry_key=key,
            legend_name=s.name,
            source_name=s.source_name,
            source_path=entry.source_path,
            y_label=s.y_label,
            y_unit=s.y_unit,
            y_unit_label=s.y_unit_label,
            y=y_grid,
            y_display_prefix=s.y_display_prefix,
            sample_mode=s.sample_mode,
            logic_states=logic_states_grid,
        ))

    y_units = {t.y_unit for t in traces}
    if len(y_units) > 2:
        raise ValueError("At most two distinct y-axis units are supported.")

    return AlignedPlotData(
        x_seconds=x_grid,
        traces=traces,
        x_timestep_seconds=dt,
        x_display_prefix=series_list[0].x_display_prefix if series_list else None,
    )


# ---------------------------------------------------------------------------
# Expression evaluation
# ---------------------------------------------------------------------------

def evaluate_expressions(
    aligned: AlignedPlotData,
    expr_defs: list[ExpressionDef],
    registry: dict[str, _RegistryEntry],
) -> list[AlignedTrace]:
    """Evaluate named expressions and return new AlignedTraces."""
    if not expr_defs:
        return []

    x = aligned.x_seconds

    # Build lookup maps from registry keys
    trace_by_key: dict[str, AlignedTrace] = {t.registry_key: t for t in aligned.traces}

    # Expression namespace: name → EvalResult (checked before registry)
    expr_ns: dict[str, EvalResult] = {}

    produced: list[AlignedTrace] = []

    for expr_def in expr_defs:
        name = expr_def.name
        if name in expr_ns:
            raise ValueError(f"Duplicate expression name: {name!r}")

        _, ast = parse_expr_def(f"{name}={expr_def.expr_text}")

        def make_resolve(
            trace_by_key: dict[str, AlignedTrace] = trace_by_key,
            expr_ns: dict[str, EvalResult] = expr_ns,
            registry: dict[str, _RegistryEntry] = registry,
        ):
            def resolve(a_pat: str | None, b_pat: str, context: str) -> EvalResult:
                # 1. Check expression namespace first (exact name match on b_pat)
                if a_pat is None and b_pat in expr_ns and not any(c in b_pat for c in "*?[]"):
                    return expr_ns[b_pat]

                # 2. Pattern-match against registry keys
                a_match = _glob_to_match_pattern(a_pat) if a_pat is not None else "*"
                b_match = _glob_to_match_pattern(b_pat)

                matches: list[tuple[str, AlignedTrace]] = []
                for key, trace in trace_by_key.items():
                    realpath_str, series_name = key.rsplit("|", 1)
                    file_base = Path(realpath_str).name
                    if fnmatch.fnmatch(file_base, a_match) and fnmatch.fnmatch(series_name, b_match):
                        matches.append((key, trace))

                if context == "scalar":
                    if len(matches) == 0:
                        raise ValueError(
                            f"Series reference {_fmt_ref(a_pat, b_pat)!r} matched no loaded series"
                        )
                    if len(matches) > 1:
                        names = ", ".join(k for k, _ in matches)
                        raise ValueError(
                            f"Series reference {_fmt_ref(a_pat, b_pat)!r} is ambiguous — "
                            f"matched {len(matches)} series: {names}"
                        )
                    t = matches[0][1]
                    return EvalResult(
                        value=t.y,
                        y_unit=t.y_unit,
                        y_unit_label=t.y_unit_label,
                        y_label=t.y_label,
                        sample_mode=t.sample_mode,
                    )

                # array context (used by sum())
                if not matches:
                    raise ValueError(
                        f"Series reference {_fmt_ref(a_pat, b_pat)!r} matched no loaded series"
                    )
                units = {t.y_unit for _, t in matches}
                if len(units) > 1:
                    raise ValueError(
                        f"Cannot sum series with different units "
                        f"({', '.join(sorted(units))}) in reference {_fmt_ref(a_pat, b_pat)!r}"
                    )
                first = matches[0][1]
                return EvalResult(
                    value=[t.y for _, t in matches],
                    y_unit=first.y_unit,
                    y_unit_label=first.y_unit_label,
                    y_label=b_pat,
                    sample_mode=_common_sample_mode([t for _, t in matches]),
                )

            return resolve

        result = evaluate(ast, make_resolve(), x)

        # Expand scalar (float) to horizontal line
        val = result.value
        if isinstance(val, float):
            if not np.isfinite(val):
                arr = np.full_like(x, np.nan, dtype=np.float64)
            else:
                arr = np.full_like(x, val, dtype=np.float64)
            expr_ns[name] = EvalResult(
                value=arr,
                y_unit=result.y_unit,
                y_unit_label=result.y_unit_label,
                y_label=result.y_label or name,
                sample_mode=result.sample_mode,
            )
            produced.append(AlignedTrace(
                registry_key=f"expr|{name}",
                legend_name=name,
                source_name=f"expr[{expr_def.expr_text}]",
                source_path=None,
                y_label=result.y_label or name,
                y_unit=result.y_unit,
                y_unit_label=result.y_unit_label,
                y=arr,
                sample_mode=result.sample_mode,
            ))

        elif isinstance(val, np.ndarray):
            expr_ns[name] = EvalResult(
                value=val,
                y_unit=result.y_unit,
                y_unit_label=result.y_unit_label,
                y_label=result.y_label or name,
                sample_mode=result.sample_mode,
            )
            produced.append(AlignedTrace(
                registry_key=f"expr|{name}",
                legend_name=name,
                source_name=f"expr[{expr_def.expr_text}]",
                source_path=None,
                y_label=result.y_label or name,
                y_unit=result.y_unit,
                y_unit_label=result.y_unit_label,
                y=val,
                sample_mode=result.sample_mode,
            ))

        elif isinstance(val, list):
            # Array-of-series is internal-only (sum() aggregation). Ordinary
            # references resolve in scalar context and reject multiple matches
            # as ambiguous, so a top-level list is unreachable. Fail loudly
            # rather than silently expanding name|1, name|2 traces.
            raise ValueError(
                f"Expression {name!r} produced multiple series; "
                f"use sum() to aggregate or a narrower pattern"
            )
        else:
            raise TypeError(f"Expression {name!r} returned unsupported type {type(val)}")

    return produced


def combine_plot_data(
    aligned_files: AlignedPlotData,
    expression_traces: list[AlignedTrace],
) -> AlignedPlotData:
    if not expression_traces:
        return aligned_files
    all_traces = [*aligned_files.traces, *expression_traces]
    y_units = {t.y_unit for t in all_traces}
    if len(y_units) > 2:
        raise ValueError("At most two distinct y-axis units are supported.")
    return AlignedPlotData(
        x_seconds=aligned_files.x_seconds,
        traces=all_traces,
        x_timestep_seconds=aligned_files.x_timestep_seconds,
        x_display_prefix=aligned_files.x_display_prefix,
    )


def clip_aligned(
    data: AlignedPlotData,
    x_min: float | None = None,
    x_max: float | None = None,
) -> AlignedPlotData:
    if x_min is not None and x_max is not None and x_min > x_max:
        raise ValueError(f"--xmin ({x_min}) is greater than --xmax ({x_max})")
    mask = np.ones(data.x_seconds.size, dtype=bool)
    if x_min is not None:
        mask &= data.x_seconds >= x_min
    if x_max is not None:
        mask &= data.x_seconds <= x_max
    if not np.any(mask):
        raise ValueError("Clip range contains no samples")
    x = data.x_seconds[mask]
    traces = [
        AlignedTrace(
            registry_key=t.registry_key,
            legend_name=t.legend_name,
            source_name=t.source_name,
            source_path=t.source_path,
            y_label=t.y_label,
            y_unit=t.y_unit,
            y_unit_label=t.y_unit_label,
            y=t.y[mask],
            y_display_prefix=t.y_display_prefix,
            sample_mode=t.sample_mode,
            logic_states=t.logic_states[mask] if t.logic_states is not None else None,
        )
        for t in data.traces
    ]
    return AlignedPlotData(
        x_seconds=x,
        traces=traces,
        x_timestep_seconds=data.x_timestep_seconds,
        x_display_prefix=data.x_display_prefix,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt_ref(a: str | None, b: str) -> str:
    if a is None:
        return b
    return f"{a}|{b}"


def _common_sample_mode(traces: list[AlignedTrace]) -> SampleMode:
    return "step" if traces and all(t.sample_mode == "step" for t in traces) else "linear"


def _merge_duplicate_x(
    x: np.ndarray,
    y: np.ndarray,
    logic_states: np.ndarray | None,
    sample_mode: SampleMode,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    """Merge duplicate x values. Step signals keep the last value at each instant."""
    if x.size == 0:
        return x, y, logic_states
    # np.unique sorts and deduplicates; use return_inverse to sum/count groups
    unique_x, inverse = np.unique(x, return_inverse=True)
    if unique_x.size == x.size:
        return x, y, logic_states
    if sample_mode == "step":
        # Linear-time last-wins: single reverse pass maps each unique x to
        # its final sample index (input is non-decreasing, so duplicates are
        # contiguous). Avoids quadratic repeated full scans.
        last_idx = np.full(unique_x.size, -1, dtype=np.intp)
        remaining = unique_x.size
        for pos in range(x.size - 1, -1, -1):
            ui = int(inverse[pos])
            if last_idx[ui] == -1:
                last_idx[ui] = pos
                remaining -= 1
                if remaining == 0:
                    break
        unique_y = y[last_idx].astype(np.float64)
        unique_logic_states = (
            logic_states[last_idx].astype(np.str_)
            if logic_states is not None
            else None
        )
        return unique_x, unique_y, unique_logic_states
    counts = np.bincount(inverse, minlength=unique_x.size).astype(np.float64)
    unique_y = np.bincount(inverse, weights=y, minlength=unique_x.size) / counts
    return unique_x, unique_y, None


def _validate_input_x_before_merge(x: np.ndarray, source_path: Path) -> None:
    # Validate original input ordering before np.unique() can sort it.
    # Empty is rejected; one-element arrays must still be finite.
    if x.size == 0:
        raise ValueError(f"Empty x-axis data in {source_path}")
    if np.any(~np.isfinite(x)):
        raise ValueError(f"Non-finite x-axis values in {source_path}")
    diffs = np.diff(x)
    if diffs.size and np.any(diffs < 0):
        bad_idx = int(np.argmax(diffs < 0)) + 2  # 1-based row in original order
        raise ValueError(f"x-axis data must be non-decreasing in {source_path} (line {bad_idx})")


def _validate_strictly_increasing_x(x: np.ndarray, source_path: Path) -> None:
    if x.size == 0:
        raise ValueError(f"Empty x-axis data in {source_path}")
    if np.any(~np.isfinite(x)):
        raise ValueError(f"Non-finite x-axis values in {source_path}")
    diffs = np.diff(x)
    if diffs.size == 0:
        return
    if np.any(diffs <= 0):
        bad_idx = int(np.argmax(diffs <= 0)) + 2  # 1-based line of the offending row
        raise ValueError(f"x-axis data must be strictly increasing in {source_path} (line {bad_idx})")


def _smallest_positive_dx(x_arrays: list[np.ndarray]) -> float:
    mins: list[float] = []
    for x in x_arrays:
        diffs = np.diff(x)
        positive = diffs[diffs > 0]
        if positive.size:
            mins.append(float(np.min(positive)))
    if not mins:
        raise ValueError("Could not determine global x-axis timestep")
    return min(mins)


def _uniform_grid(x_min: float, x_max: float, dt: float) -> np.ndarray:
    if dt <= 0:
        raise ValueError("Global timestep must be > 0")
    span = x_max - x_min
    if span < 0:
        raise ValueError("x_max must be >= x_min")
    ratio = span / dt if dt else 0.0
    steps = max(0, int(np.floor(ratio + 1e-12)))
    grid = x_min + (np.arange(steps + 1, dtype=np.float64) * dt)
    if grid.size == 0:
        return np.asarray([x_min], dtype=np.float64)
    if grid[-1] < x_max and not np.isclose(grid[-1], x_max):
        grid = np.append(grid, x_max)
    return grid


def _range_tol(x0: float, x1: float) -> float:
    # Tolerance based on floating-point representational error (scaled eps),
    # not an application-scale fraction of the timestep, so sources are never
    # extrapolated outside their true range.
    return float(max(1.0, abs(x0), abs(x1)) * np.finfo(np.float64).eps * 100)


def _interpolate_onto_grid(x: np.ndarray, y: np.ndarray, x_grid: np.ndarray) -> np.ndarray:
    y_grid = np.full_like(x_grid, np.nan, dtype=np.float64)
    if x.size == 0:
        return y_grid
    tol = _range_tol(float(x[0]), float(x[-1]))
    mask = (x_grid >= (x[0] - tol)) & (x_grid <= (x[-1] + tol))
    if np.any(mask):
        xg = np.clip(x_grid[mask], x[0], x[-1])
        y_grid[mask] = np.interp(xg, x, y).astype(np.float64)
    return y_grid


def _step_onto_grid(x: np.ndarray, y: np.ndarray, x_grid: np.ndarray) -> np.ndarray:
    y_grid = np.full_like(x_grid, np.nan, dtype=np.float64)
    if x.size == 0:
        return y_grid
    tol = _range_tol(float(x[0]), float(x[-1]))
    mask = (x_grid >= (x[0] - tol)) & (x_grid <= (x[-1] + tol))
    if np.any(mask):
        indexes = np.searchsorted(x, x_grid[mask], side="right") - 1
        indexes = np.clip(indexes, 0, x.size - 1)
        y_grid[mask] = y[indexes].astype(np.float64)
    return y_grid


def _step_states_onto_grid(x: np.ndarray, states: np.ndarray | None, x_grid: np.ndarray) -> np.ndarray | None:
    if states is None:
        return None
    state_grid = np.full(x_grid.shape, "", dtype=np.str_)
    if x.size == 0:
        return state_grid
    tol = _range_tol(float(x[0]), float(x[-1]))
    mask = (x_grid >= (x[0] - tol)) & (x_grid <= (x[-1] + tol))
    if np.any(mask):
        indexes = np.searchsorted(x, x_grid[mask], side="right") - 1
        indexes = np.clip(indexes, 0, x.size - 1)
        state_grid[mask] = states[indexes]
    return state_grid
