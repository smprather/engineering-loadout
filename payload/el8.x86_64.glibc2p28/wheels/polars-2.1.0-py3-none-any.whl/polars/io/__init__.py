"""Functions for reading data."""

from polars.io.arrow_c_stream import scan_arrow_c_stream
from polars.io.avro import read_avro
from polars.io.clipboard import read_clipboard
from polars.io.csv import read_csv, scan_csv
from polars.io.database import read_database, read_database_uri
from polars.io.delta import read_delta, scan_delta
from polars.io.external_reader.api import scan_external_reader
from polars.io.iceberg import delete_iceberg, scan_iceberg
from polars.io.ipc import read_ipc, read_ipc_schema, read_ipc_stream, scan_ipc
from polars.io.json import read_json
from polars.io.lance import scan_lance
from polars.io.lines import read_lines, scan_lines
from polars.io.ndjson import read_ndjson, scan_ndjson
from polars.io.parquet import (
    ParquetDecryptionProperties,
    ParquetEncryptionProperties,
    read_parquet,
    read_parquet_metadata,
    read_parquet_schema,
    scan_parquet,
)
from polars.io.partition import (
    FileProviderArgs,
    PartitionBy,
)
from polars.io.plugins import _defer as defer
from polars.io.pyarrow_dataset import scan_pyarrow_dataset
from polars.io.scan_options import ScanCastOptions
from polars.io.spreadsheet import read_excel, read_ods

__all__ = [
    "defer",
    "delete_iceberg",
    "FileProviderArgs",
    "ParquetDecryptionProperties",
    "ParquetEncryptionProperties",
    "PartitionBy",
    "read_avro",
    "read_clipboard",
    "read_csv",
    "read_database",
    "read_database_uri",
    "read_delta",
    "read_excel",
    "read_ipc",
    "read_ipc_schema",
    "read_ipc_stream",
    "read_json",
    "read_lines",
    "read_ndjson",
    "read_ods",
    "read_parquet",
    "read_parquet_metadata",
    "read_parquet_schema",
    "scan_arrow_c_stream",
    "scan_csv",
    "scan_delta",
    "scan_external_reader",
    "scan_iceberg",
    "scan_ipc",
    "scan_lance",
    "scan_lines",
    "scan_ndjson",
    "scan_parquet",
    "scan_pyarrow_dataset",
    "ScanCastOptions",
]
