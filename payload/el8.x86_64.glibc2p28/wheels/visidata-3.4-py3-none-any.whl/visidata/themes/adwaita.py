'Adwaita theme with light and dark variants using 256-colors.'

from visidata import vd

vd.themes["adwaita_light"] = dict(
    color_default="0 on 15",
    color_default_hdr="bold 0 on 15",
    color_bottom_hdr="underline 0 on 15",
    color_current_row="reverse",
    color_current_col="bold",
    color_current_hdr="bold reverse",
    color_column_sep="7 on 15",
    color_key_col="26 blue",
    color_edit_cell="26 blue",
    color_selected_row="0 on 111",
    color_note_row="178 yellow",
    color_note_type="26 blue",
    color_warning="178 yellow",
    color_error="160 red",
    color_status="bold 0 on 15",
    color_menu="0 on 15",
    color_menu_active="15 on 26 blue",
    color_menu_help="244 on 15",
    color_active_status="15 on 26 blue",
    color_inactive_status="246 on 15",
    color_working="bold 36 green",
    color_add_pending="36 green",
    color_change_pending="reverse 178 yellow",
    color_delete_pending="160 red",
    plot_colors="26 36 178 160 134 38"
)

vd.themes["adwaita_dark"] = dict(
    color_default="15 on 234",
    color_default_hdr="bold 15 on 234",
    color_bottom_hdr="underline 15 on 234",
    color_current_row="reverse",
    color_current_col="bold",
    color_current_hdr="bold reverse",
    color_column_sep="59 on 234",
    color_key_col="68 blue",
    color_edit_cell="68 blue",
    color_selected_row="234 on 15",
    color_note_row="214 yellow",
    color_note_type="68 blue",
    color_warning="214 yellow",
    color_error="203 red",
    color_status="bold 15 on 235",
    color_menu="15 on 235",
    color_menu_active="234 on 68 blue",
    color_menu_help="246 on 235",
    color_active_status="234 on 68 blue",
    color_inactive_status="246 on 234",
    color_working="bold 78 green",
    color_add_pending="78 green",
    color_change_pending="reverse 214 yellow",
    color_delete_pending="203 red",
    plot_colors="68 78 214 203 134 38"
)
