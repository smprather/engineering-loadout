"""Terminal plots via plotext v6 (headless, static).

Renders an :class:`AlignedPlotData` as colored (or plain) ASCII text for
stdout. Analog-first: logic step traces are rejected with a clear error
(use the HTML output for those). Up to two distinct y-units are supported
(second unit goes on plotext's right y-axis), mirroring the HTML limit.
"""

from __future__ import annotations

import numpy as np
import plotext as plt

from time_plot.plotting import _dedupe_labels
from time_plot.processing import AlignedPlotData, AlignedTrace
from time_plot.units import scale_for_display


def render_ascii(
    plot_data: AlignedPlotData,
    *,
    title: str = "Time Plot",
    width: int = 80,
    height: int = 30,
    colorless: bool = False,
) -> str:
    """Render aligned traces as a plotext figure string.

    NaN gaps are never passed to plotext (its backend cannot handle them);
    each contiguous finite run becomes its own signal segment with lines.
    Only the first segment per trace carries the legend label.
    """
    if not plot_data.traces:
        raise ValueError("No traces to plot")
    for trace in plot_data.traces:
        if trace.y_unit == "logic" and trace.sample_mode == "step":
            raise ValueError(
                "ASCII output does not support logic traces "
                f"({trace.legend_name!r}); use the HTML output instead."
            )

    units = _ordered_y_units(plot_data.traces)
    if len(units) > 2:
        msg = "ASCII output supports at most two y-axis units."
        raise ValueError(msg)

    x_scaled = scale_for_display(
        plot_data.x_seconds,
        base_unit="s",
        forced_prefix=plot_data.x_display_prefix,
    )
    legend_names = _dedupe_labels([trace.legend_name for trace in plot_data.traces])

    y_factors: dict[str, float] = {}
    y_labels: dict[str, str] = {}
    for unit in units:
        unit_traces = [t for t in plot_data.traces if t.y_unit == unit]
        values = (
            np.concatenate([t.y[np.isfinite(t.y)] for t in unit_traces])
            if unit_traces
            else np.array([], dtype=np.float64)
        )
        forced_prefixes = {t.y_display_prefix for t in unit_traces if t.y_display_prefix is not None}
        forced_prefix = next(iter(forced_prefixes)) if len(forced_prefixes) == 1 else None
        scaled = scale_for_display(
            values if values.size else np.asarray([0.0]),
            base_unit=unit,
            forced_prefix=forced_prefix,
        )
        y_factors[unit] = scaled.factor
        y_labels[unit] = f"{unit_traces[0].y_unit_label} ({scaled.display_unit})" if unit_traces else unit

    # plotext's master figure is global state; always reset it, even on error.
    fig = plt.figure
    fig.clear()
    try:
        fig.plot_size(width, height)
        fig.title(title)
        fig.label(f"Time ({x_scaled.display_unit})", axis="x")
        fig.label(y_labels[units[0]], axis="y", side="left")
        if len(units) > 1:
            fig.label(y_labels[units[1]], axis="y", side="right")

        for i, trace in enumerate(plot_data.traces):
            yside = "left" if trace.y_unit == units[0] else "right"
            scaled_y = trace.y / y_factors[trace.y_unit]
            first_segment = True
            for run_x, run_y in _finite_runs(x_scaled.scaled_values, scaled_y):
                signal = fig.signal(run_x.tolist(), run_y.tolist(), yside=yside)
                if run_x.size > 1:
                    signal.lines()
                if first_segment:
                    signal.label(legend_names[i])
                    first_segment = False
                fig.draw(signal)

        return fig.build().string(colorless=colorless)
    finally:
        fig.clear()


def _ordered_y_units(traces: list[AlignedTrace]) -> list[str]:
    seen: set[str] = set()
    units: list[str] = []
    for trace in traces:
        if trace.y_unit in seen:
            continue
        seen.add(trace.y_unit)
        units.append(trace.y_unit)
    return units


def _finite_runs(
    x: np.ndarray, y: np.ndarray
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Split x/y into contiguous runs where both are finite."""
    mask = np.isfinite(x) & np.isfinite(y)
    if not np.any(mask):
        return []
    idx = np.nonzero(mask)[0]
    breaks = np.nonzero(np.diff(idx) > 1)[0]
    runs: list[tuple[np.ndarray, np.ndarray]] = []
    start = 0
    for break_at in breaks:
        segment = idx[start : break_at + 1]
        runs.append((x[segment], y[segment]))
        start = break_at + 1
    segment = idx[start:]
    runs.append((x[segment], y[segment]))
    return runs
