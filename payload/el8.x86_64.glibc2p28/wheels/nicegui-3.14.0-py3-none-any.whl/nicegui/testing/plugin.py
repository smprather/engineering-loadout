# pylint: disable=unused-import
from .general_fixtures import nicegui_reset_globals, pytest_addoption  # noqa: F401
from .screen_plugin import (  # noqa: F401
    nicegui_chrome_options,
    nicegui_driver,
    nicegui_remove_all_screenshots,
    pytest_configure,  # wraps general_fixtures' to also set up Screen.PORT/SCREENSHOT_DIR/DOWNLOAD_DIR
    pytest_runtest_makereport,
    screen,
)
from .user_plugin import create_user, user  # noqa: F401
