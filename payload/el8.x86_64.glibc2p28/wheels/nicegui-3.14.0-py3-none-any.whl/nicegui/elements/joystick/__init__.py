from typing import TYPE_CHECKING

from ...dependencies import setup_esm_package

__getattr__, __dir__ = setup_esm_package(__file__, __name__, 'nicegui-joystick', {'Joystick': '.joystick'})
__all__ = ['Joystick']

if TYPE_CHECKING:
    from .joystick import Joystick
