#!/usr/bin/env python3
import json
import os
import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

from rich import box
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# from peek import peek as p

MIN_PYTHON = (3, 9)
if sys.version_info < MIN_PYTHON:
    sys.exit("Python %s.%s or later is required.\n" % MIN_PYTHON)

# p.color = "yellow"
# p.color_value = "red"

DISTRIBUTION_NAME = "tmux-path-store"
g_script = Path(sys.argv[0]).stem
console = Console()

g_help_rows = (
    ("Navigate", "cdh", "cd home directory (same as cd0)"),
    ("Navigate", "cd[0-9]", "cd to directory #"),
    ("Navigate", "f[0-9]", "Edit file # with $EDITOR"),
    ("Store", "shd, sdh", "Set home directory (same as sd0)"),
    ("Store", "sd[0-9] [dir]", "Set directory # to pwd, or optional dir"),
    ("Store", "sf[0-9] <file>", "Set file # to <file>"),
    ("Inspect", "ld, lf", "List directories/files for current window"),
    ("Inspect", "lda, lfa", "List directories/files for all windows"),
    ("Inspect", "lw", "List all windows"),
    ("Manage", "rd[0-9], rf[0-9]", "Reset file/directory #"),
    ("Manage", "dw [<window>...]", "Delete window store. Defaults to current window"),
    ("Manage", "swd, swf <#> <#>", "Swap dir/file index1 with index2"),
    ("Help", "tps", "Print this help"),
)


def eprint(msg, then_exit=True, rc=1):
    """Since we are normally having the stdout eval'd by the shell, error messages
    should go to stderr. Then send a 'false' command for eval by the shell which
    produces an non-zero return code (rc=1).
    """
    rprint(f"[i]{g_script}[/i]: [bold red]Error[/bold red]: {msg}", file=sys.stderr)
    if then_exit:
        print("false", end="")
        sys.exit(rc)


def wprint(msg):
    """Since we are normally having the stdout eval'd by the shell, error messages
    should go to stderr. Then send a 'false' command for eval by the shell which
    produces an non-zero return code (rc=1).
    """
    rprint(f"[i]{g_script}[/i]: [bold yellow]Warning[/bold yellow]: {msg}", file=sys.stderr)


def print_window_contents(db: dict[str, dict[str, list[str]]], window_name: str, ford: str):
    rprint(f"[bold][deep_sky_blue4]Window: [dodger_blue1]{window_name}")
    for i in range(0, 10):
        console.print(f"{i}: {db[window_name][ford][i]}", soft_wrap=True)


def print_help():
    table = Table(
        box=box.SIMPLE_HEAVY,
        border_style="bright_black",
        header_style="bold white",
        pad_edge=False,
        show_edge=False,
    )
    table.add_column("Mode", style="bold deep_sky_blue4", no_wrap=True)
    table.add_column("Alias", style="bold dodger_blue1", no_wrap=True)
    table.add_column("Action", style="white")

    for mode, alias, action in g_help_rows:
        table.add_row(mode, Text(alias, style="bold cyan"), action)

    console.print(
        Panel(
            table,
            title=Text("tmux-path-store aliases", style="bold dodger_blue1"),
            subtitle=Text("eval $(tmux_path_store --bash)", style="dim"),
            border_style="deep_sky_blue4",
            padding=(1, 2),
        )
    )


def cli():
    if len(sys.argv) < 2 or sys.argv[1] in ["-h", "--help", "help"]:
        print_help()
        sys.exit()

    if sys.argv[1] in ["--version", "version"]:
        print(f"{DISTRIBUTION_NAME} {version(DISTRIBUTION_NAME)}")
        sys.exit()

    # Add "eval $(tmux_path_store --bash)" to your .bashrc to get these aliases
    if sys.argv[1] == "--bash":
        for alias in (
            f"alias ld='{g_script} list-dirs'; ",
            f"alias lf='{g_script} list-files'; ",
            f"alias lda='{g_script} list-dirs __all__'; ",
            f"alias lfa='{g_script} list-files __all__'; ",
            f"alias lw='{g_script} list-windows'; ",
            f"alias dw='{g_script} delete-window'; ",
            f"alias cdh='eval $({g_script} cd 0)'; ",
            f"alias shd='{g_script} set-dir 0'; ",
            f"alias sdh='{g_script} set-dir 0'; ",
            f"alias swd='{g_script} swap-dirs'; ",
            f"alias swf='{g_script} swap-files'; ",
            f'ef() {{ eval $({g_script} edit-files "$@"); }}; ',
            f"alias tps='{g_script} help'; ",
            "for x in $(seq 0 9); do ",
            f'    alias cd$x="eval \\$({g_script} cd $x)"; ',
            f'    alias sd$x="{g_script} set-dir $x"; ',
            f'    alias sf$x="{g_script} set-file $x"; ',
            f'    alias rd$x="{g_script} reset-dir $x"; ',
            f'    alias rf$x="{g_script} reset-file $x"; ',
            f'    alias f$x="eval \\$({g_script} edit-file $x)"; ',
            "done",
        ):
            print(alias.lstrip(), end="")
        print("")
        sys.exit()

    db_dir = Path(f"{os.environ['HOME']}/.local/state/{g_script}")
    if not db_dir.exists():
        db_dir.mkdir(parents=True, exist_ok=True)
    db_file = db_dir / "db.json"
    sub_cmd = sys.argv[1]
    if len(sys.argv) > 2:
        args = sys.argv[2:]
    else:
        args = []

    if "dir" in sub_cmd:
        ford = "dirs"
    elif "file" in sub_cmd:
        ford = "files"
    else:
        ford = ""

    if not (window := os.getenv("TMUX_WINDOW")):
        if os.getenv("TMUX"):
            # Already inside a tmux session; use tmux from PATH (avoids stale binary cache issues)
            tmux_cmd = "tmux"
        else:
            user = os.environ["USER"]
            tmux_server_binary_holder_file = Path(f"/tmp/{g_script}_server_binary.{user}")

            tmux_server_binary = None
            if tmux_server_binary_holder_file.exists():
                tmux_server_binary = Path(tmux_server_binary_holder_file.read_text())
                if not tmux_server_binary.exists():
                    tmux_server_binary_holder_file.unlink(missing_ok=True)
                    tmux_server_binary = None

            if tmux_server_binary is None:
                try:
                    tmux_server_binary = Path(
                        "/proc/"
                        + subprocess.run(
                            ["/usr/bin/pgrep", "-f", "-u", user, "tmux$"],
                            capture_output=True,
                            text=True,
                        ).stdout.split()[0]
                        + "/exe"
                    ).resolve()
                    tmux_server_binary_holder_file.write_text(str(tmux_server_binary))
                except IndexError:
                    eprint("We do not appear to be in a tmux session.")

            tmux_cmd = str(tmux_server_binary)

        try:
            window = (
                subprocess.check_output(
                    f"{tmux_cmd} display-message -p '#W'",
                    shell=True,
                )
                .decode("utf-8")
                .rstrip()
            )
        except subprocess.CalledProcessError:
            eprint(
                "There was a problem running tmux display-message -p '#W'.\n"
                "There is probably not a running tmux session on this host.\n"
                "Try pgrep -u $USER -a tmux."
            )

    assert window
    if db_file.exists():
        with db_file.open(encoding="utf-8") as fh:
            db = json.load(fh)
    else:
        db = dict()

    if sub_cmd not in [
        "set-dir",
        "set-file",
        "list-windows",
        "list-all-windows",
    ]:
        if window not in db:
            eprint(
                f"Window {window} is not in the db. Use set-dir/set-file to init this window.\n"
                "You should have shd/sd/sf aliases to these sub-commands."
            )

    write_db = False

    if sub_cmd == "cd":
        dir_lookup = db[window]["dirs"][int(args[0])]
        if dir_lookup == "":
            eprint(f"Directory {args[0]} is not defined for window '{window}'.")
        else:
            print(f"cd {dir_lookup}", end="")

    elif sub_cmd == "edit-file":
        lookup = db[window]["files"][int(args[0])]
        if lookup == "":
            eprint(f"File {args[0]} is not defined for window '{window}'.")
        else:
            print(f"$EDITOR {lookup}", end="")

    elif sub_cmd == "edit-files":
        files = []
        for file_num in [int(x) for x in args]:
            lookup = db[window]["files"][file_num]
            if lookup == "":
                wprint(f"File {args[0]} is not defined for window '{window}'.")
            else:
                files.append(lookup)
        print(f"$EDITOR {' '.join(files)}", end="")

    elif sub_cmd in ["list-dirs", "list-files"]:
        if args == ["__all__"]:
            # Print the current window contents last
            for window_name in [x for x in sorted(db.keys()) if x != window]:
                print_window_contents(db, window_name, ford)
            print_window_contents(db, window, ford)
        elif len(args) > 0:
            for window_name in args:
                if window_name in db:
                    print_window_contents(db, window_name, ford)
                else:
                    wprint(f"Window {window_name} has not been defined.")
        else:
            print_window_contents(db, window, ford)

    elif sub_cmd == "set-dir":
        db[window] = db.get(window) or dict(dirs=[""] * 10, files=[""] * 10)
        if len(args) > 1:
            db[window][ford][int(args[0])] = args[1]
        else:
            db[window][ford][int(args[0])] = os.getcwd()
        write_db = True
    elif sub_cmd == "set-file":
        db[window] = db.get(window) or dict(dirs=[""] * 10, files=[""] * 10)
        # If no file is given, default to the most recently modified
        if len(args) == 1:
            most_recent_modified = subprocess.getoutput(
                "find . -maxdepth 1 -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-"
            )
            if most_recent_modified == "":
                eprint("There are no files in this directory.")
            args.append(os.path.realpath(most_recent_modified))

        if os.path.exists(args[1]):
            realpath = Path(args[1]).resolve()
            if not realpath.is_file():
                eprint(f"'{args[1]}' (realpath: '{realpath}') is not a file. Not storing.")
            db[window][ford][int(args[0])] = os.path.realpath(args[1])
            write_db = True
        else:
            eprint(f"File {args[1]} does not exist. Not storing.")

    elif sub_cmd in ["reset-dir", "reset-file"]:
        db[window][ford][int(args[0])] = ""
        write_db = True

    elif sub_cmd in ["get-dir", "get-file"]:
        lookup = db[window][ford][int(args[0])]
        if lookup == "":
            eprint(f"Directory {args[0]} is not defined for window '{window}'.")
        print(lookup)

    elif sub_cmd == "list-windows":
        print("Windows:")
        for window_name in sorted(db.keys()):
            print("  ", window_name)

    elif sub_cmd == "delete-window":
        # Default to the current window
        if len(args) == 0:
            args = [window]
        for window_name in args:
            if window_name in db.keys():
                del db[window_name]
            else:
                wprint(f"The window '{window_name}' is not in the db.")
        write_db = True

    elif sub_cmd in ["swap-dirs", "swap-files"]:
        src, dest = [int(arg) for arg in args]
        temp = db[window][ford][dest]
        db[window][ford][dest] = db[window][ford][src]
        db[window][ford][src] = temp
        write_db = True

    else:
        eprint(f"Unrecognized sub-command '{sub_cmd}'.")

    if write_db:
        with db_file.open(mode="w", encoding="utf-8") as fh:
            json.dump(db, fh, separators=(",", ":"))


if __name__ == "__main__":
    cli()
