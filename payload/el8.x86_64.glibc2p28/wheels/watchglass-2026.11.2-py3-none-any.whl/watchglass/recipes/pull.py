"""recipe = "pull": copy settled files from a remote directory into a local staging folder.

The `remote_files` observer reports settled remote files (with their sha256). check() answers TRUE with the
files not yet pulled; on_true() pulls each one (verified) and records it in the ledger "pulled", which also tells
the observer which files to skip when it reconnects.

With delete_remote, each verified file is queued in "to_delete" (with the sha256 it was verified with) and
deleted from the source host by watchglass's remote helper, which first checks that it is still exactly that
file. Deleted or gone keys leave "pulled" for "skipped" (forgotten after 7 days; stale events for them are ignored); changed ones just leave "pulled" (the new version is pulled when reported); refused ones go to "kept". Files pulled while delete_remote was off have no recorded sha256 and are never deleted (an entry without one goes to "kept"). A file that is gone from the source by the time its pull runs (the producer moved, renamed or deleted it) is withdrawn, not failed: with `on_missing = "skip"` (the default) it is recorded in "skipped" with a WARNING and the poll succeeds, so the event is acknowledged instead of failing forever behind the rest of the queue (`on_missing = "fail"` keeps the strict behavior). See watchglass docs recipes.
"""

from __future__ import annotations

import contextlib
import json
import subprocess
import time
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

from watchglass.ctx import CommandFailed, Ctx, as_text
from watchglass.recipes import Failures, file_budget
from watchglass.remote import ssh_argv, watcher_source
from watchglass.transfer import (
    TransferAuthFailed,
    TransferFailed,
    TransferMismatch,
    TransferMissing,
    format_bytes,
    with_known_hosts,
)

LEDGER = "pulled"
TO_DELETE = "to_delete"
SKIPPED = "skipped"
KEPT = "kept"
SKIP_FOR = "7d"
UNKNOWN_SHA = "-"


def event_key(event: dict[str, Any]) -> str:
    """The ledger key of a remote file: "<path>|<size>|<mtime!r>" (the remote watcher builds the same text)."""
    return f"{event['path']}|{event['size']}|{event['mtime']!r}"


def transfer_options(settings: Mapping[str, Any]) -> dict[str, Any]:
    options = {name: settings[name] for name in ("protocol", "port", "identity", "known_hosts")
               if settings[name] is not None}
    return {**options, "ssh_options": list(settings["ssh_options"])}


def queue_key(key: str, sha256: str | None) -> str:
    """A to_delete entry: the pulled file's key plus the sha256 it was verified with ("-" when unknown)."""
    return f"{key}|{sha256 or UNKNOWN_SHA}"


def split_queue_key(entry: str) -> tuple[str, dict[str, Any]]:
    """(the pulled key, the helper's {"path", "size", "mtime", "sha256"?}) for a to_delete entry."""
    key, sha256 = entry.rsplit("|", 1)
    path, size, mtime = key.rsplit("|", 2)
    item: dict[str, Any] = {"path": path, "size": int(size), "mtime": float(mtime)}
    if sha256 != UNKNOWN_SHA:
        item["sha256"] = sha256
    return key, item


def due_deletions(ctx: Ctx) -> list[str]:
    """Queued deletions due for an attempt (only files pulled and verified while delete_remote was on are queued)."""
    settings = ctx.settings
    if not settings["delete_remote"]:
        return []
    pending = ctx.ledger(TO_DELETE)
    now = datetime.now(timezone.utc)
    return [entry for entry in pending
            if (now - cast(datetime, pending.added_at(entry))).total_seconds() >= settings["delete_retry"]]


def delete_remote(ctx: Ctx, entries: list[str]) -> None:
    """Delete these pulled files from the source host in one ssh call; problems are logged and retried."""
    if not entries:
        return
    settings = ctx.settings
    pending, pulled, kept = ctx.ledger(TO_DELETE), ctx.ledger(LEDGER), ctx.ledger(KEPT)
    skipped = ctx.ledger(SKIPPED, expire=SKIP_FOR)
    remote = settings["remote"]
    queued = [(entry, *split_queue_key(entry)) for entry in entries]
    for entry, key, item in queued:
        if "sha256" not in item:
            pending.discard(entry)
            kept.add(key)
            name = item["path"].rsplit("/", 1)[-1]
            ctx.log.warning("not deleting %s on %s: no verified sha256 was recorded for it (delete it by hand)", name, remote)
    queued = [(entry, key, item) for entry, key, item in queued if "sha256" in item]
    if not queued:
        return
    argv = ssh_argv(
        remote,
        port=settings["port"],
        identity=settings["identity"],
        ssh_options=with_known_hosts(settings["ssh_options"], settings["known_hosts"]),
        ssh_command=settings["ssh_command"],
        remote_python=settings["remote_python"],
    )
    options = {"mode": "delete", "dir": settings["remote_dir"], "files": [item for _, _, item in queued]}
    try:
        completed = ctx.run(argv, input=watcher_source(options), check=False)
        stdout, stderr = completed.stdout, completed.stderr
    except subprocess.TimeoutExpired as exc:
        # Keep what the helper reported before the deadline: files it already deleted are not retried.
        stdout = as_text(exc.stdout)
        stderr = as_text(exc.stderr) + "\ntimed out (for large files raise action_timeout: the helper re-reads each one)"
    except OSError as exc:
        stdout, stderr = "", str(exc)
    results: dict[int, dict[str, Any]] = {}
    for line in stdout.splitlines():
        try:
            message = json.loads(line)
        except ValueError:
            continue
        if isinstance(message, dict) and isinstance(message.get("index"), int):
            results[message["index"]] = message
    swept = 0
    for index, (entry, key, item) in enumerate(queued):
        name = item["path"].rsplit("/", 1)[-1]
        result = results.get(index)
        event = result["event"] if result else None
        if event in ("deleted", "gone"):
            pending.discard(entry)
            pulled.discard(key)
            skipped.add(key)
            swept += 1
            if event == "deleted":
                ctx.log.info("deleted %s from %s", name, remote)
            else:
                ctx.log.info("%s was already gone from %s", name, remote)
        elif event == "changed":
            pending.discard(entry)
            pulled.discard(key)  # not skipped: the new content is pulled when it is reported
            ctx.log.warning("%s changed on %s since it was pulled; kept there", name, remote)
        elif event == "refused":
            pending.discard(entry)
            kept.add(key)
            reason = (result or {}).get("reason")
            ctx.log.warning("not deleting %s on %s: %s", name, remote, reason)
        else:
            pending.add(entry)  # refreshes its stamp: retried after delete_retry
            if result is not None:
                reason = result.get("reason")
            else:
                reason = " | ".join(stderr.strip().splitlines()[-3:]) or "no answer"
            ctx.log.warning("could not delete %s from %s (will retry): %s", name, remote, reason)
    if swept:
        ctx.event(f"swept {swept} file(s) from {remote}", count=swept, remote=remote)


def check(ctx: Ctx) -> tuple[bool, list[dict[str, Any]]]:
    settings = ctx.settings
    pulled = ctx.ledger(LEDGER)
    skipped = ctx.ledger(SKIPPED, expire=SKIP_FOR)
    new: list[dict[str, Any]] = []
    seen: set[str] = set()
    for event in ctx.events:
        if event.get("event") != "file":
            continue
        key = event_key(event)
        if key in pulled or key in skipped or key in seen:
            continue
        seen.add(key)
        item = {"path": event["path"], "name": event["name"], "size": event["size"],
                "sha256": event.get("sha256"), "key": key}
        new.append(item)
        ctx.event(f"found {item['name']} ({format_bytes(item['size'])}) on {settings['remote']}",
                  name=item["name"], size=item["size"], remote=settings["remote"])
    return bool(new) or bool(due_deletions(ctx)), new


def cleanup_parts(ctx: Ctx, directory: Path, max_age: float) -> None:
    """Delete `.NAME.part` files left by killed attempts (older than `part_max_age`); 0 disables the cleanup."""
    if max_age <= 0:
        return
    cutoff = time.time() - max_age
    for part in sorted(directory.rglob(".*.part")):
        try:
            info = part.stat()
        except OSError:
            continue
        if info.st_mtime < cutoff:
            part.unlink(missing_ok=True)
            ctx.log.warning("deleted %s (%s left by a killed transfer)", part.name, format_bytes(info.st_size))


def on_true(ctx: Ctx) -> None:
    settings = ctx.settings
    pulled = ctx.ledger(LEDGER)
    skipped = ctx.ledger(SKIPPED, expire=SKIP_FOR)
    queue = ctx.ledger(TO_DELETE) if settings["delete_remote"] else None
    options = transfer_options(settings)
    fresh: list[str] = []
    pulled_now = 0
    failures = Failures()
    try:
        items = [item for item in ctx.payload if item["key"] not in pulled and item["key"] not in skipped]
        # One ledger rewrite for the whole queue instead of one per file: "pulled" only grows, so saving per
        # key would rewrite (and fsync) an ever larger document N times for N files.
        with contextlib.ExitStack() as ledgers:
            for ledger in (pulled, skipped, queue):
                if ledger is not None:
                    ledgers.enter_context(ledger.batch())
            for index, item in enumerate(items):
                if ctx.remaining <= 0:
                    failures.note(TransferFailed("no time left for the rest of this queue (raise action_timeout)"))
                    break
                sha256 = item["sha256"] if settings["checksum"] else None
                # A fair share of what is left, so one slow file cannot starve the rest of the queue (`file_timeout`
                # caps it harder). A file that fails or runs out of its share is logged and the queue carries on.
                budget = file_budget(ctx.remaining, len(items) - index, settings["file_timeout"])
                part = Path(settings["local_dir"]) / f".{Path(item['path']).name}.part"
                resumed = 0
                if settings["resume"]:
                    with contextlib.suppress(OSError):
                        resumed = part.stat().st_size
                if resumed:
                    ctx.event(
                        f"resuming {item['name']} at {format_bytes(resumed)} of {format_bytes(item['size'])} "
                        f"from {settings['remote']}",
                        name=item["name"], size=item["size"], offset=resumed, remote=settings["remote"],
                    )
                else:
                    ctx.event(f"pulling {item['name']} ({format_bytes(item['size'])}) from {settings['remote']}",
                              name=item["name"], size=item["size"], remote=settings["remote"])
                started = time.monotonic()
                try:
                    final = ctx.transfer.pull(
                        f"{settings['remote']}:{item['path']}",
                        settings["local_dir"],
                        size=item["size"],
                        sha256=sha256,
                        on_conflict=settings["on_conflict"],
                        resume=settings["resume"],
                        deadline=time.time() + budget,
                        **options,
                    )
                except TransferAuthFailed:
                    # Permanent: stop the queue instead of repeating the same failed login for every file.
                    raise
                except TransferMismatch as exc:
                    # The file changed after it was reported; its new version comes as a new event.
                    ctx.event(f"{item['name']} changed on {settings['remote']} after it was reported ({exc}); "
                              "not pulled", level="WARNING", name=item["name"], remote=settings["remote"])
                    continue
                except TransferMissing as exc:
                    # The producer withdrew the file between the report and this pull: a permanent condition for
                    # this event, so retrying it would fail forever and starve the real queue behind it (issue 14).
                    if settings["on_missing"] == "fail":
                        failures.note(exc)
                        ctx.event(f"pulling {item['name']} from {settings['remote']} failed ({exc}); "
                                  "the rest of the queue is still tried",
                                  level="WARNING", name=item["name"], remote=settings["remote"])
                    else:
                        skipped.add(item["key"])
                        # A resumable attempt keeps its partial when it fails; a file that is gone never uses it.
                        with contextlib.suppress(OSError):
                            part.unlink(missing_ok=True)
                        ctx.event(f"{item['name']} is gone from {settings['remote']} "
                                  "(withdrawn after it was reported); skipping it",
                                  level="WARNING", name=item["name"], remote=settings["remote"])
                    continue
                except (TransferFailed, CommandFailed, OSError) as exc:
                    failures.note(exc)
                    ctx.event(f"pulling {item['name']} from {settings['remote']} failed ({exc}); "
                              "the rest of the queue is still tried",
                              level="WARNING", name=item["name"], remote=settings["remote"])
                    continue
                if queue is not None:  # queued first: a crash before the next line still gets the file deleted
                    entry = queue_key(item["key"], sha256)
                    queue.add(entry)
                    fresh.append(entry)
                pulled.add(item["key"])
                pulled_now += 1
                duration = time.monotonic() - started
                ctx.event(f"pulled {item['name']} ({format_bytes(item['size'])}) in {duration:.1f}s",
                          local=str(final), size=item["size"], duration=round(duration, 3))
        if pulled_now:
            cleanup_parts(ctx, Path(settings["local_dir"]), settings["part_max_age"])
    except Exception as exc:  # deletes below still run for what was pulled; the error is raised after them
        failures.note(exc)
    if queue is not None and (fresh or not failures):
        entries = set(fresh) if failures else set(fresh) | set(due_deletions(ctx))
        try:
            delete_remote(ctx, sorted(entries))
        except Exception as exc:
            if not failures:
                raise
            failures.note(exc)
            ctx.log.warning("deleting from %s failed as well: %s", settings["remote"], exc)
    failures.raise_if_any()
