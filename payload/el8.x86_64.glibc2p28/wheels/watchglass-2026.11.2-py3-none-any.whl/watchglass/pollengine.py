"""One poll of one watch: check (or fake), state machine, actions, log records."""

from __future__ import annotations

import functools
import time
import uuid
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

from watchglass.config import GlobalConfig, WatchConfig
from watchglass.hooks import CHECK, NO_CHECK, watch_hooks
from watchglass.logstore import Sink, make_record
from watchglass.offline import iso_time
from watchglass.paths import Paths
from watchglass.runner import FAILED_STATUSES, HookCall, HookResult, Runner
from watchglass.state import Outcome, WatchState, finish_poll, plan_poll

_PLUGIN_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
_COMMAND_FIELDS = (
    "argv",
    "shell",
    "exit_code",
    "timed_out",
    "duration",
    "stdout",
    "stderr",
    "stdout_truncated",
    "stderr_truncated",
)


def parse_fakes(spec: str) -> list[Outcome]:
    """Parse "true,false,timeout" into outcomes."""
    valid = ", ".join(outcome.value for outcome in Outcome)
    outcomes = []
    for part in spec.split(","):
        word = part.strip()
        try:
            outcomes.append(Outcome(word.lower()))
        except ValueError:
            raise ValueError(f"'{word}' is not an outcome; use a comma-separated list of: {valid}") from None
    return outcomes


@dataclass(frozen=True)
class Fake:
    outcome: Outcome
    payload: Any = None


@dataclass
class PollReport:
    poll_id: str
    watch: str
    outcome: Outcome
    reason: str | None
    payload: Any
    before: WatchState
    after: WatchState
    planned: tuple[str, ...]
    results: list[HookResult] = field(default_factory=list)
    failed: bool = False
    faked: bool = False
    dry_run: bool = False
    trial: bool = False
    permanent_reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "poll_id": self.poll_id,
            "watch": self.watch,
            "outcome": self.outcome.value,
            "reason": self.reason,
            "payload": self.payload,
            "condition_before": self.before.condition,
            "condition_after": self.after.condition,
            "pending_edge": self.after.pending_edge.value if self.after.pending_edge else None,
            "failures": self.after.failures,
            "rejections": self.after.rejections,
            "planned_actions": list(self.planned),
            "results": [{"hook": result.hook, "status": result.status, "reason": result.reason} for result in self.results],
            "failed": self.failed,
            "faked": self.faked,
            "dry_run": self.dry_run,
            "trial": self.trial,
            "permanent_reason": self.permanent_reason,
        }


def _edge(state: WatchState) -> str | None:
    return state.pending_edge.value if state.pending_edge else None


class PollEngine:
    def __init__(self, *, runner: Runner, paths: Paths, global_config: GlobalConfig, sink: Sink, pid: int) -> None:
        self._runner = runner
        self._paths = paths
        self._global = global_config
        self._sink = sink
        self._pid = pid

    def set_global_config(self, global_config: GlobalConfig) -> None:
        """Use a reloaded global config from the next hook call on."""
        self._global = global_config

    @property
    def global_config(self) -> GlobalConfig:
        return self._global

    @property
    def pid(self) -> int:
        """The process whose run dirs this engine's hooks use (the service, or a manual poll)."""
        return self._pid

    def poll(
        self,
        watch: WatchConfig,
        state: WatchState,
        *,
        fake: Fake | None = None,
        dry_run: bool = False,
        trial: bool = False,
        events: Sequence[dict[str, Any]] = (),
        on_hook: Callable[[dict[str, Any] | None], None] | None = None,
    ) -> PollReport:
        poll_id = uuid.uuid4().hex[:12]
        events = tuple(events)
        tag = {"watch": watch.name, "poll_id": poll_id}
        faked = fake is not None
        self._sink(make_record("poll.start", **tag, condition=state.condition, faked=faked, dry_run=dry_run, trial=trial, events=len(events)))
        hooks, problem = watch_hooks(watch.watch_dir, watch.hooks, watch.recipe)
        check_permanent: str | None = None
        if problem is None and fake is None and CHECK not in hooks:
            problem = NO_CHECK
        if problem is not None:
            outcome, reason, payload = Outcome.ERROR, problem, None
        elif fake is not None:
            outcome, reason, payload = fake.outcome, "faked with --fake", fake.payload
        else:
            result = self._run(watch, CHECK, poll_id, state.condition, None, watch.check_timeout, events, on_hook)
            outcome, reason, payload = result.outcome(), result.reason, result.payload
            if result.status in FAILED_STATUSES:
                check_permanent = result.permanent_reason
        plan = plan_poll(state, outcome, hooks)
        answered = outcome in (Outcome.TRUE, Outcome.FALSE, Outcome.UNKNOWN)
        self._sink(
            make_record(
                "check.outcome",
                level="INFO" if answered else "ERROR",
                **tag,
                outcome=outcome.value,
                reason=reason,
                payload=payload,
                condition_before=state.condition,
                condition_after=plan.state.condition,
                pending_edge=_edge(plan.state),
                actions=list(plan.actions),
                faked=faked,
            )
        )
        results: list[HookResult] = []
        rejection: str | None = None
        if dry_run:
            after, failed = finish_poll(plan, [(hook, True) for hook in plan.actions])
        else:
            for hook in plan.actions:
                result = self._run(watch, hook, poll_id, plan.state.condition, payload, watch.action_timeout, events,
                                   on_hook)
                results.append(result)
                if not result.succeeded:
                    break
            rejection = check_permanent or next(
                (result.permanent_reason for result in results if not result.succeeded and result.permanent_reason),
                None,
            )
            after, failed = finish_poll(
                plan, [(result.hook, result.succeeded) for result in results], rejection=rejection
            )
        self._sink(
            make_record(
                "poll.end",
                level="WARNING" if failed else "INFO",
                **tag,
                failed=failed,
                failures=after.failures,
                rejections=after.rejections,
                permanent_reason=rejection if not dry_run else None,
                condition=after.condition,
                pending_edge=_edge(after),
                dry_run=dry_run,
            )
        )
        return PollReport(
            poll_id=poll_id,
            watch=watch.name,
            outcome=outcome,
            reason=reason,
            payload=payload,
            before=state,
            after=after,
            planned=plan.actions,
            results=results,
            failed=failed,
            faked=faked,
            dry_run=dry_run,
            trial=trial,
            permanent_reason=rejection if not dry_run else None,
        )

    def _emit_message(self, tag: dict[str, Any], message: dict[str, Any]) -> None:
        if message.get("type") == "command":
            fields = {key: message.get(key) for key in _COMMAND_FIELDS}
            level = "INFO" if message.get("exit_code") == 0 else "WARNING"
            self._sink(make_record("command", level=level, **tag, **fields))
            return
        level = str(message.get("level")) if message.get("level") in _PLUGIN_LEVELS else "INFO"
        if message.get("type") == "event":
            self._sink(
                make_record(
                    "plugin.event",
                    level=level,
                    **tag,
                    message=message.get("message"),
                    fields=message.get("fields") or {},
                )
            )
            return
        self._sink(
            make_record(
                "plugin.log",
                level=level,
                **tag,
                logger=message.get("logger"),
                message=message.get("message"),
                fields=message.get("fields") or {},
                traceback=message.get("traceback"),
            )
        )

    def _run(
        self,
        watch: WatchConfig,
        hook: str,
        poll_id: str,
        condition: bool,
        payload: Any,
        timeout: float,
        events: tuple[dict[str, Any], ...],
        on_hook: Callable[[dict[str, Any] | None], None] | None = None,
    ) -> HookResult:
        tag = {"watch": watch.name, "poll_id": poll_id, "hook": hook}
        call = HookCall(
            watch=watch,
            hook=hook,
            poll_id=poll_id,
            condition=condition,
            payload=payload,
            data_dir=self._paths.watch_data_dir(watch.name),
            run_dir=self._paths.run_dir(self._pid, watch.name),
            timeout=timeout,
            capture_bytes=self._global.log.capture_bytes,
            environment=self._global.environment,
            environment_file=self._global.environment_file,
            events=events,
            on_message=functools.partial(self._emit_message, tag),
        )
        if on_hook is not None:
            on_hook({"hook": hook, "poll_id": poll_id, "timeout": timeout, "started_at": iso_time(time.time())})
        try:
            result = self._runner.run(call)
        finally:
            if on_hook is not None:
                on_hook(None)  # nothing of this watch is running for the moment
        for message in result.messages:
            self._emit_message(tag, message)
        level = "ERROR" if result.status in FAILED_STATUSES else "INFO"
        self._sink(make_record("hook.end", level=level, watch=watch.name, poll_id=poll_id, **result.to_record()))
        return result
