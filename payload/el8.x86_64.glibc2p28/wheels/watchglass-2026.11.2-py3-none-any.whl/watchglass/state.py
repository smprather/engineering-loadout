"""The per-watch state machine (spec section 7) and backoff (section 8.2). Pure: no I/O."""

from __future__ import annotations

from collections.abc import Collection, Sequence
from dataclasses import dataclass, replace
from enum import StrEnum


class Outcome(StrEnum):
    TRUE = "true"
    FALSE = "false"
    UNKNOWN = "unknown"
    TIMEOUT = "timeout"
    ERROR = "error"


ANSWERS = frozenset({Outcome.TRUE, Outcome.FALSE})
CHECK_FAILURES = frozenset({Outcome.TIMEOUT, Outcome.ERROR})


class Edge(StrEnum):
    RISE = "rise"
    FALL = "fall"


EDGE_HOOKS = {Edge.RISE: "on_rise", Edge.FALL: "on_fall"}
BACKOFF_BASE = 60.0
BACKOFF_CAP = 3600.0


@dataclass(frozen=True)
class WatchState:
    condition: bool
    pending_edge: Edge | None = None
    failures: int = 0
    rejections: int = 0  # consecutive permanent failures (a rejected credential or host key)


def initial_state(initial_condition: bool) -> WatchState:
    """The state a watch starts in: `initial_condition` for the condition, and its edge still to be run.

    A watch configured `initial_condition = true` starts as a TRUE condition that has not announced itself, so
    its first successful poll runs `on_rise` and then `on_true` - the behaviour `docs states` describes, and the
    useful one for a one-shot ("tell me now if the site is already down"). A FALSE answer replaces the edge.
    """
    return WatchState(condition=initial_condition, pending_edge=Edge.RISE if initial_condition else None)


@dataclass(frozen=True)
class Plan:
    """What a poll will do: the state after the outcome, and the actions to run in order."""

    state: WatchState
    outcome: Outcome
    actions: tuple[str, ...]
    check_failed: bool


def plan_poll(state: WatchState, outcome: Outcome, defined_hooks: Collection[str]) -> Plan:
    """Apply a check outcome to the state and list the actions to run (section 7.1)."""
    if outcome not in ANSWERS:
        return Plan(state, outcome, (), outcome in CHECK_FAILURES)
    condition = outcome is Outcome.TRUE
    pending = state.pending_edge
    if condition != state.condition:
        pending = Edge.RISE if condition else Edge.FALL
    actions: list[str] = []
    if pending is not None:
        edge_hook = EDGE_HOOKS[pending]
        if edge_hook in defined_hooks:
            actions.append(edge_hook)
        else:
            pending = None
    level_hook = "on_true" if condition else "on_false"
    if level_hook in defined_hooks:
        actions.append(level_hook)
    return Plan(replace(state, condition=condition, pending_edge=pending), outcome, tuple(actions), False)


def finish_poll(
    plan: Plan, results: Sequence[tuple[str, bool]], rejection: str | None = None
) -> tuple[WatchState, bool]:
    """Fold action results (hook, succeeded) into the state. Returns (state, poll_failed).

    `rejection` is the short reason a failure is permanent (a rejected credential or host key); the count
    survives ordinary failures and resets only on a poll that succeeds, so default `max_auth_failures = 1`
    parks the watch on its first rejection while a larger value tolerates that many.
    """
    failed = plan.check_failed or any(not succeeded for _, succeeded in results)
    pending = plan.state.pending_edge
    if pending is not None and (EDGE_HOOKS[pending], True) in results:
        pending = None
    rejections = plan.state.rejections
    if failed:
        failures = plan.state.failures + 1
        if rejection is not None:
            rejections += 1
    elif plan.outcome in ANSWERS:
        failures = 0
        rejections = 0
    else:
        failures = plan.state.failures
    return replace(plan.state, pending_edge=pending, failures=failures, rejections=rejections), failed


def next_delay(interval: float, failures: int) -> float:
    """Seconds to wait before the next poll (section 8.2)."""
    if failures <= 0:
        return interval
    base = max(interval, BACKOFF_BASE)
    cap = max(interval, BACKOFF_CAP)
    # The exponent is clamped before the power, not after: max_failures = 0 lets the count grow for as long as
    # the watch fails, and both 2 ** 1024 and 2.0 ** 1024 raise OverflowError (before min() could clamp). 64
    # doublings already pass any cap (cap/base is at most 1h/60s = 60), so the clamp cannot change the result.
    return min(base * 2.0 ** min(failures - 1, 64), cap)


def should_go_offline(failures: int, max_failures: int) -> bool:
    return max_failures > 0 and failures >= max_failures


def should_park_for_rejection(rejections: int, max_auth_failures: int) -> bool:
    """Whether this many consecutive credential/host-key rejections park the watch (0 disables it)."""
    return max_auth_failures > 0 and rejections >= max_auth_failures
