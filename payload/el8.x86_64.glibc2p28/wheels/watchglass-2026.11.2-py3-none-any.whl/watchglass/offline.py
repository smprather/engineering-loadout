"""offline.json: a watch stopped by the failure limit or by `watchglass disable` (spec 8.3)."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any

from watchglass.paths import Paths, write_json_atomic


def iso_time(epoch: float) -> str:
    """Local time as RFC 3339 with offset and milliseconds, clamped to the calendar's range.

    A huge `interval` (whatever the parser accepts) puts `next_poll` past year 9999. Raising there would abort
    `write_status`, freezing status.json for every watch, so the far ends of the calendar are rendered instead.
    """
    try:
        return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="milliseconds")
    except (OverflowError, OSError, ValueError):
        return "9999-12-31T23:59:59.999+00:00" if epoch > 0 else "0001-01-01T00:00:00.000+00:00"


@dataclass(frozen=True)
class OfflineMarker:
    reason: str
    since: str
    by_user: bool = False
    last_failure: str | None = None
    permanent: bool = False  # a rejected credential/host key: no trial polls will ever succeed (issue 24)

    def since_epoch(self) -> float:
        try:
            return datetime.fromisoformat(self.since).timestamp()
        except ValueError:
            return 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def read_offline(paths: Paths, watch: str) -> OfflineMarker | None:
    path = paths.offline_file(watch)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return OfflineMarker(
            reason=str(data["reason"]),
            since=str(data["since"]),
            by_user=bool(data.get("by_user", False)),
            last_failure=data.get("last_failure"),
            permanent=bool(data.get("permanent", False)),
        )
    except FileNotFoundError:
        return None
    except (OSError, ValueError, TypeError, KeyError):
        return OfflineMarker(
            reason=f"{path} is unreadable; run: watchglass enable {watch}",
            since=iso_time(time.time()),
            by_user=True,
        )


def write_offline(paths: Paths, watch: str, marker: OfflineMarker) -> None:
    write_json_atomic(paths.offline_file(watch), marker.to_dict())


def clear_offline(paths: Paths, watch: str) -> bool:
    try:
        paths.offline_file(watch).unlink()
    except FileNotFoundError:
        return False
    return True
