# The terminal monitor (`watchglass tui`)

`watchglass tui` is a live view of what the service is doing: every watch with its state and how long
until its next poll, and the stream of actions with their results. It reads `status.json` once a second and
follows the log file. Its only write is a poke request - `p` asks the running service to poll the selected
watch now. Everything else it touches is the service lock file it opens to ask whether the service is
running, so it is safe beside a running service, and several monitors may run at once.

`status.json` carries a `format` number (currently 1): new fields are added without notice, and that number goes
up only if an existing field changes meaning, so a consumer can rely on the ones it knows.

## What it shows

- **The banner**: whether the service is running, its pid and version, and how old the status is. When the
  service is not running — or its status is more than a few seconds old — the age is marked stale, `NEXT` shows
  `—` instead of a countdown, and the rest is the last known status.
- **The table**: one row per watch. `WATCH`; `STATE` (`online`, `polling`, `transferring`, `offline`, `parked`,
  `idle`, `invalid`, `orphaned`); `COND`; `FAIL`; `LAST` (outcome and age); `NEXT` (a countdown, `due`, or
  `retry …` for an offline watch); `OBS` (running observers); and `NOTE`, the first thing that is wrong: an
  invalid config, a config error, a missing directory, orphaned state, queued events, a user-disabled watch —
  or, while a transfer runs, the file being moved.
- **What is running right now**: the service puts the hook it is running (`in_flight`) and what that hook is
  transferring (`transfer`, with the partial file's size) into `status.json`, so `watchglass status` and this
  monitor show them without reading the log. A long transfer therefore reads `transferring` rather than
  `polling`, and `NOTE` names the file.
- **The pane**: the selected watch's recent records, oldest first — the same lines `watchglass logs` prints.
  While a hook is running the pane header names it and how long it has been going: `recipe pull:on_true running
  1m30s · pulling psg-export.gz 74% (2.6 GiB/3.7 GiB), 2.1 MiB/s, 8m left`. A transfer says how far it has got
  (from the partial file's size), how fast and how long is left once there are two samples of it; an upload says
  its size, since scp reports no progress of its own.

Below 80 columns `NOTE` is dropped, and then `OBS`.

## Verbosity

The pane starts at **normal**. `v` cycles quiet → normal → verbose → quiet; the banner shows the current level.
The table, the banner and the pane header are unaffected: this only filters the pane's log lines.

| Level | Shows |
| --- | --- |
| quiet | failures, `watch.offline`/`watch.online`, service errors, alerts — state changes only |
| normal | + headlines (`plugin.event`), condition edges with their actions, hook results, watches added/removed, config reloads, observer connect/drop |
| verbose | + every poll's `poll.start`/`poll.end`, `check.outcome` detail, commands, captured stdout/stderr, payloads, observer events |

A record that watchglass does not recognise yet stays visible at verbose rather than disappearing.

## Keys

| Key | What it does |
| --- | --- |
| `q`, `Ctrl-C` | quit |
| `↑`/`↓`, `j`/`k` | select a watch |
| `a` | every watch's records instead of the selected one's |
| `v` | cycle the pane's verbosity: quiet → normal → verbose |
| `space` | pause the pane (records keep arriving; the header counts them) |
| `p` | poke the selected watch: ask the running service to poll it now |
| `r` | re-read the config now (new and removed watches) |

The mouse works too: a click selects a row, and the wheel scrolls the pane.

## What it is not

It cannot enable or disable a watch, and it cannot poll without the service: `p` writes a request file only
when the service is running (otherwise it says so and writes nothing). It keeps the last few hundred records in
memory and does not browse history (use `watchglass logs` for that), and it needs a terminal: scripts and
agents use `watchglass status --json` and `watchglass logs --json`, which are the machine-readable interface.

## When a poll is in flight

An action that runs for a long time (a large transfer, say) writes no log record until it ends, so the monitor
marks the watch `polling` from the poll's own `poll.start` record (or `transferring` once `status.json` has a
live transfer), shows how long it has been running and which of its hooks have already finished. It believes
that only while the service runs with a fresh status: when the service stops or restarts, the mark goes away.
