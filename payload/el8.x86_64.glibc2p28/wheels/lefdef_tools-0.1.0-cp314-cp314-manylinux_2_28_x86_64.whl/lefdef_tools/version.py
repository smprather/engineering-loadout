from __future__ import annotations

import re
import subprocess
from importlib import metadata
from pathlib import Path

DIST_NAME = "lefdef-tools"
_SEMVER_RE = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)(.*)$")


def get_version() -> str:
    """Return installed version, or setuptools-scm-style version in a git clone."""
    package = _package_version()
    root = _find_git_root(Path(__file__).resolve())
    if root is None:
        return package
    return _git_version(root, package) or package


def _package_version() -> str:
    try:
        return metadata.version(DIST_NAME)
    except metadata.PackageNotFoundError:
        return "0.0.0"


def _find_git_root(start: Path) -> Path | None:
    for path in (start, *start.parents):
        if (path / ".git").exists():
            return path
    return None


def _git_version(root: Path, package_version: str) -> str | None:
    description = _git(
        root,
        "describe",
        "--tags",
        "--long",
        "--dirty",
        "--match",
        "v[0-9]*",
        "--match",
        "[0-9]*",
    )
    if description:
        parsed = _version_from_describe(description)
        if parsed:
            return parsed
    return _version_from_hash(root, package_version)


def _version_from_describe(description: str) -> str | None:
    dirty = description.endswith("-dirty")
    if dirty:
        description = description.removesuffix("-dirty")

    parts = description.rsplit("-", 2)
    if len(parts) != 3:
        return None
    tag, distance_text, hash_text = parts
    if not distance_text.isdigit() or not hash_text.startswith("g"):
        return None

    base = _strip_v(tag)
    distance = int(distance_text)
    if distance == 0:
        version = base
    else:
        version = f"{_bump_patch(base)}.dev{distance}+{hash_text}"
    return _append_dirty(version) if dirty else version


def _version_from_hash(root: Path, package_version: str) -> str | None:
    commit = _git(root, "rev-parse", "--short", "HEAD")
    count = _git(root, "rev-list", "--count", "HEAD")
    if not commit or not count or not count.isdigit():
        return None
    version = f"{_bump_patch(package_version)}.dev{count}+g{commit}"
    dirty = _git(root, "status", "--porcelain", "--untracked-files=no")
    return _append_dirty(version) if dirty else version


def _strip_v(version: str) -> str:
    return version[1:] if version.startswith("v") else version


def _bump_patch(version: str) -> str:
    match = _SEMVER_RE.match(version)
    if match is None:
        return version
    major, minor, patch, suffix = match.groups()
    if suffix:
        return _strip_v(version)
    return f"{major}.{minor}.{int(patch) + 1}"


def _append_dirty(version: str) -> str:
    return f"{version}.dirty" if "+" in version else f"{version}+dirty"


def _git(root: Path, *args: str) -> str:
    try:
        proc = subprocess.run(
            ["git", "-C", str(root), *args],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    if proc.returncode != 0:
        return ""
    return proc.stdout.strip()
