from __future__ import annotations

from inspect import isasyncgenfunction, isclass, isfunction, isgeneratorfunction, ismethod
from typing import TYPE_CHECKING, Any, Literal, TypeVar

from typing_extensions import Annotated, TypeAlias

from litestar.exceptions import ImproperlyConfiguredException
from litestar.types import Empty
from litestar.utils import ensure_async_callable
from litestar.utils.predicates import is_async_callable
from litestar.utils.warnings import (
    warn_implicit_sync_to_thread,
    warn_sync_to_thread_with_async_callable,
    warn_sync_to_thread_with_generator,
)

if TYPE_CHECKING:
    from litestar._signature import SignatureModel
    from litestar.types import AnyCallable
    from litestar.utils.signature import ParsedSignature

__all__ = (
    "NamedDependency",
    "Provide",
)


T = TypeVar("T")


class Dependency:
    def __init__(self, kind: Literal["named"] = "named") -> None:
        # currently only 'named' kind is supported, and this value isn't used. 3.0 will
        # introduce the 'type' kind
        self.kind = kind


NamedDependency: TypeAlias = Annotated[T, Dependency(kind="named")]
"""
Mark a parameter for name-based dependency injection.

The name of the function parameter will be used as the name for the dependency to inject.
"""


class Provide:
    """Wrapper class for dependency injection"""

    __slots__ = (
        "dependency",
        "has_async_generator_dependency",
        "has_sync_callable",
        "has_sync_generator_dependency",
        "parsed_fn_signature",
        "signature_model",
        "sync_to_thread",
        "use_cache",
        "value",
    )

    parsed_fn_signature: ParsedSignature
    signature_model: type[SignatureModel]
    dependency: AnyCallable

    def __init__(
        self,
        dependency: AnyCallable | type[Any],
        use_cache: bool = False,
        sync_to_thread: bool | None = None,
    ) -> None:
        """Initialize ``Provide``

        Args:
            dependency: Callable to call or class to instantiate. The result is then injected as a dependency.
            use_cache: Cache the dependency return value. Defaults to False.
            sync_to_thread: Run sync code in an async thread. Defaults to False.
        """
        if not callable(dependency):
            raise ImproperlyConfiguredException("Provider dependency must be a callable value")

        is_class_dependency = isclass(dependency)
        is_function = isfunction(dependency)
        is_method = ismethod(dependency)
        is_callable_instance = not is_class_dependency and not is_function and not is_method
        if is_class_dependency or is_callable_instance:
            check_target = dependency.__call__  # type: ignore[operator]
        else:
            check_target = dependency
        self.has_sync_generator_dependency = isgeneratorfunction(check_target)
        self.has_async_generator_dependency = isasyncgenfunction(check_target)

        has_generator_dependency = self.has_sync_generator_dependency or self.has_async_generator_dependency

        if has_generator_dependency and use_cache:
            raise ImproperlyConfiguredException(
                "Cannot cache generator dependency, consider using Lifespan Context instead."
            )

        has_sync_callable = is_class_dependency or not is_async_callable(dependency)  # pyright: ignore

        if sync_to_thread is not None:
            if has_generator_dependency:
                warn_sync_to_thread_with_generator(dependency, stacklevel=3)  # type: ignore[arg-type]
            elif not has_sync_callable:
                warn_sync_to_thread_with_async_callable(dependency, stacklevel=3)  # pyright: ignore
        elif has_sync_callable and not has_generator_dependency:
            warn_implicit_sync_to_thread(dependency, stacklevel=3)  # pyright: ignore

        if sync_to_thread and has_sync_callable:
            self.dependency = ensure_async_callable(dependency)  # pyright: ignore
            self.has_sync_callable = False
        else:
            self.dependency = dependency  # pyright: ignore
            self.has_sync_callable = has_sync_callable

        self.sync_to_thread = bool(sync_to_thread)
        self.use_cache = use_cache
        self.value: Any = Empty

    async def __call__(self, **kwargs: Any) -> Any:
        """Call the provider's dependency."""

        if self.use_cache and self.value is not Empty:
            return self.value

        if self.has_sync_callable:
            value = self.dependency(**kwargs)
        else:
            value = await self.dependency(**kwargs)

        if self.use_cache:
            self.value = value

        return value

    def __eq__(self, other: Any) -> bool:
        # check if memory address is identical, otherwise compare attributes
        return other is self or (
            isinstance(other, self.__class__)
            and other.dependency == self.dependency
            and other.use_cache == self.use_cache
            and other.value == self.value
        )
